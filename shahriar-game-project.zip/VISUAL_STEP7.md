# Visual Step 7 — Settings + Hero Vault

- Settings به System Control حرفه‌ای تبدیل شد.
- Game Rules، XP/Level، Rank، دسته‌بندی Task و Player Profile کارت‌های گیمی مجزا دارند.
- تمام ورودی‌ها و منطق ذخیره/Reset قبلی حفظ شده است.
- Hero Picker به Hero Vault تبدیل شد.
- Preview بزرگ Hero انتخاب‌شده، نام، Trait و Style مجهز نمایش داده می‌شود.
- تب آقایان/خانم‌ها و هر 8 Hero قبلی حفظ شده‌اند.
- انتخاب Hero همچنان در Lobby و Gameplay اعمال می‌شود.
- Visual Steps 1 تا 6 داخل پروژه باقی مانده‌اند.
