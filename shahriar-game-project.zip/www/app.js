const STORAGE_KEY = 'shahriar_game_state_v1';

const defaultState = {
  playerName: 'شهریار',
  level: 28,
  xp: 6240,
  xpMax: 8000,
  gold: 2437,
  diamonds: 12,
  rank: 'حماسی III',
  rankIndex: 3,
  rankTier: 'III',
  selectedHero: 'young_stylish',
  tasks: [
    {id:'t1', name:'ارتباط‌سازی با ۳ نفر', category:'شبکه‌سازی', difficulty:'medium', xp:30, gold:30, diamonds:1, active:true, note:''},
    {id:'t2', name:'یک پیش‌مشاوره', category:'شبکه‌سازی', difficulty:'medium', xp:30, gold:25, diamonds:0, active:true, note:''},
    {id:'t3', name:'دعوت برای معرفی کار', category:'شبکه‌سازی', difficulty:'hard', xp:40, gold:40, diamonds:1, active:true, note:''},
    {id:'t4', name:'مرتب کردن اتاق', category:'شخصی', difficulty:'easy', xp:10, gold:10, diamonds:0, active:true, note:''},
    {id:'t5', name:'۲۰ دقیقه مطالعه', category:'یادگیری', difficulty:'easy', xp:15, gold:15, diamonds:0, active:true, note:''}
  ],
  matchHistory: [],
  lifetimeStats: {
    matches: 0,
    wins: 0,
    playSeconds: 0,
    tasks: 0,
    minions: 0,
    towers: 0,
    xp: 0,
    gold: 0,
    diamonds: 0
  },
  teamGoals: {
    people: 100,
    sales: 2000000000,
    gpv: 2000000,
    growth: 20
  },
  teamMembers: [],
  networkActions: [],
  schedules: [],
  timesheetWeekOffset: 0,
  shopItems: [
    {id:'hero_young_stylish', type:'hero', name:'Hero جوان', icon:'🧑🏻', note:'استایل مدرن و پرانرژی', cost:0, heroKey:'young_stylish'},
    {id:'hero_luxury_man', type:'hero', name:'Hero لاکچری', icon:'🤵🏻', note:'استایل موفق و سطح بالا', cost:900, heroKey:'mid_luxury'},
    {id:'style_gold_aura', type:'style', name:'هاله طلایی', icon:'✨', note:'افکت طلایی دور Hero در Lobby', cost:450},
    {id:'style_crown', type:'style', name:'تاج فرمانده', icon:'👑', note:'نشان ویژه Hero', cost:700},
    {id:'style_blue_aura', type:'style', name:'هاله آبی', icon:'💠', note:'افکت انرژی آبی Hero', cost:350},
    {id:'style_dark_armor', type:'style', name:'زره تاریک', icon:'🛡️', note:'ظاهر جنگجوی تاریک', cost:1100}
  ],
  ownedShopItems: ['hero_young_stylish'],
  equippedStyle: '',
  realRewards: [
    {id:'reward_movie', name:'سینما / فیلم', icon:'🎬', cost:5, note:'یک تایم کامل برای فیلم و استراحت'},
    {id:'reward_food', name:'غذای مورد علاقه', icon:'🍔', cost:7, note:'یک وعده جایزه'},
    {id:'reward_book', name:'خرید کتاب', icon:'📚', cost:10, note:'یک کتاب جدید برای خودت'}
  ],
  rewardPurchases: [],
  events: [],
  visionItems: [],
  achievements: [
    {id:'ach_daily_tasks',title:'شروع قدرتمند',period:'daily',metric:'tasks',target:3,manual:0,xp:60,gold:30,diamonds:0,icon:'⚡',note:'۳ کار واقعی داخل بازی انجام بده.',active:true,claimed:false},
    {id:'ach_week_matches',title:'جنگجوی هفته',period:'weekly',metric:'matches',target:5,manual:0,xp:150,gold:100,diamonds:1,icon:'⚔️',note:'۵ Match کامل ثبت کن.',active:true,claimed:false},
    {id:'ach_month_network',title:'شبکه‌ساز فعال',period:'monthly',metric:'network',target:20,manual:0,xp:250,gold:180,diamonds:2,icon:'🤝',note:'۲۰ اقدام شبکه‌سازی ثبت کن.',active:true,claimed:false},
    {id:'ach_long_tasks',title:'ماشین اقدام',period:'longterm',metric:'tasks',target:100,manual:0,xp:700,gold:500,diamonds:5,icon:'🏆',note:'به ۱۰۰ کار انجام‌شده در بازی برس.',active:true,claimed:false}
  ],
  achievementClaims: {},
  gameRules: {
    matchMinutes: 30,
    waveSeconds: 45,
    towerDamage: 34,
    baseDamage: 25,
    towerHp: 100,
    baseHp: 100,
    baseXpMax: 8000,
    xpGrowthPercent: 16,
    rankNames: ['جنگجو','نخبه','استاد','حماسی','افسانه‌ای','اسطوره'],
    taskCategories: ['شبکه‌سازی','فروش','جلسه','یادگیری','شخصی','پیگیری سازمان']
  }
};

let state = loadState();
state.shopItems = (state.shopItems||[]).map(item=>item.heroKey==='luxury_man'?{...item,heroKey:'mid_luxury'}:item);
state.rankIndex = Math.max(0, Math.min((state.gameRules?.rankNames?.length||1)-1, Number(state.rankIndex)||0));
let timerInterval = null;
let remainingSeconds = (Number(state.gameRules?.matchMinutes)||30) * 60;

const HEROES = {
  young_stylish: {
    name: 'آقای جوان خوش‌تیپ',
    trait: 'مدرن • جاه‌طلب • پرانرژی',
    className: 'hero-young-stylish'
  },
  mid_luxury: {
    name: 'آقای میان‌سال لاکچری',
    trait: 'لوکس • موفق • باوقار',
    className: 'hero-mid-luxury'
  },
  friendly_man: {
    name: 'آقای خوش‌برخورد',
    trait: 'اجتماعی • کاریزماتیک • صمیمی',
    className: 'hero-friendly-man'
  },
  disciplined_man: {
    name: 'آقای بادیسیپلین',
    trait: 'منظم • جدی • رهبر',
    className: 'hero-disciplined-man'
  },
  young_stylish_woman: {
    name: 'خانم جوان شیک',
    trait: 'مدرن • بااعتمادبه‌نفس • پرانرژی',
    className: 'hero-young-stylish-woman'
  },
  mid_luxury_woman: {
    name: 'خانم میان‌سال لاکچری',
    trait: 'حرفه‌ای • موفق • سطح بالا',
    className: 'hero-mid-luxury-woman'
  },
  friendly_woman: {
    name: 'خانم خوش‌برخورد',
    trait: 'اجتماعی • صمیمی • کاریزماتیک',
    className: 'hero-friendly-woman'
  },
  disciplined_woman: {
    name: 'خانم بادیسیپلین',
    trait: 'قدرتمند • منظم • مدیریتی',
    className: 'hero-disciplined-woman'
  }
};

const MOBA = {
  x: 22,
  y: 80,
  speed: 0.055,
  vx: 0,
  vy: 0,
  joystickActive: false,
  lastTs: 0,
  raf: null,
  nearby: null,
  encounterTask: null,
  encounteredEntity: null,
  entityCooldownUntil: 0,
  battleStartedAt: null,
  battleTimerInterval: null,
  deferredTaskIds: [],
  wave: 1,
  waveDuration: 45,
  waveRemaining: 45,
  waveInterval: null,
  laneProgress: {top:0, mid:0, bot:0},
  baseHp: 100,
  matchStartedAt: null,
  matchStats: {
    tasks: 0,
    minions: 0,
    towers: 0,
    xp: 0,
    gold: 0,
    diamonds: 0
  },
  resultSaved: false
};

const MAP_ENTITIES = [
  {id:'minion_1', type:'minion', lane:'top', x:54, y:29},
  {id:'minion_2', type:'minion', lane:'top', x:63, y:31},
  {id:'minion_3', type:'minion', lane:'mid', x:49, y:50},
  {id:'minion_4', type:'minion', lane:'mid', x:59, y:48},
  {id:'minion_5', type:'minion', lane:'bot', x:53, y:69},
  {id:'minion_6', type:'minion', lane:'bot', x:64, y:72},

  {id:'tower_top', type:'tower', lane:'top', stage:1, x:78, y:27},
  {id:'tower_mid', type:'tower', lane:'mid', stage:1, x:75, y:48},
  {id:'tower_bot', type:'tower', lane:'bot', stage:1, x:79, y:73},

  {id:'tower_top_2', type:'tower', lane:'top', stage:2, x:90, y:20},
  {id:'tower_mid_2', type:'tower', lane:'mid', stage:2, x:89, y:43},
  {id:'tower_bot_2', type:'tower', lane:'bot', stage:2, x:91, y:79},
  {id:'enemy_base', type:'base', x:92, y:11}
];


function loadState(){
  try{
    const saved = localStorage.getItem(STORAGE_KEY);
    if(!saved) return {...defaultState, tasks: defaultState.tasks.map(t=>({...t}))};
    const parsed = JSON.parse(saved);
    return {
      ...defaultState,
      ...parsed,
      tasks: Array.isArray(parsed.tasks) ? parsed.tasks : defaultState.tasks.map(t=>({...t})),
      matchHistory: Array.isArray(parsed.matchHistory) ? parsed.matchHistory : [],
      lifetimeStats: {
        ...defaultState.lifetimeStats,
        ...(parsed.lifetimeStats || {})
      },
      teamGoals: {
        ...defaultState.teamGoals,
        ...(parsed.teamGoals || {})
      },
      teamMembers: Array.isArray(parsed.teamMembers) ? parsed.teamMembers : [],
      networkActions: Array.isArray(parsed.networkActions) ? parsed.networkActions : [],
      schedules: Array.isArray(parsed.schedules) ? parsed.schedules : [],
      timesheetWeekOffset: Number.isFinite(parsed.timesheetWeekOffset) ? parsed.timesheetWeekOffset : 0,
      shopItems: Array.isArray(parsed.shopItems) ? parsed.shopItems : defaultState.shopItems.map(x=>({...x})),
      ownedShopItems: Array.isArray(parsed.ownedShopItems) ? parsed.ownedShopItems : [...defaultState.ownedShopItems],
      equippedStyle: parsed.equippedStyle || '',
      realRewards: Array.isArray(parsed.realRewards) ? parsed.realRewards : defaultState.realRewards.map(x=>({...x})),
      rewardPurchases: Array.isArray(parsed.rewardPurchases) ? parsed.rewardPurchases : [],
      events: Array.isArray(parsed.events) ? parsed.events : [],
      visionItems: Array.isArray(parsed.visionItems) ? parsed.visionItems : [],
      achievements: Array.isArray(parsed.achievements) ? parsed.achievements : defaultState.achievements.map(a=>({...a})),
      achievementClaims: parsed.achievementClaims && typeof parsed.achievementClaims==='object' ? parsed.achievementClaims : {},
      rankIndex: Number.isInteger(parsed.rankIndex) ? parsed.rankIndex : Math.max(0, defaultState.gameRules.rankNames.findIndex(n=>String(parsed.rank||'').startsWith(n))),
      rankTier: parsed.rankTier || (String(parsed.rank||'').match(/\b(III|II|I)\b/)?.[1] || 'III'),
      gameRules: {...defaultState.gameRules, ...(parsed.gameRules || {})}
    };
  }catch{
    return {...defaultState};
  }
}
function saveState(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function currentRankText(){
  const names=Array.isArray(state.gameRules?.rankNames)&&state.gameRules.rankNames.length?state.gameRules.rankNames:defaultState.gameRules.rankNames;
  const idx=Math.max(0,Math.min(names.length-1,Number(state.rankIndex)||0));
  return `${names[idx]} ${state.rankTier||'III'}`.trim();
}

function renderState(){
  document.getElementById('playerName').textContent = state.playerName;
  document.getElementById('levelValue').textContent = state.level;
  document.getElementById('xpValue').textContent = state.xp;
  document.getElementById('xpMax').textContent = state.xpMax;
  document.getElementById('goldValue').textContent = state.gold;
  document.getElementById('diamondValue').textContent = state.diamonds;
  document.getElementById('gamePlayerName').textContent = state.playerName;
  document.getElementById('gameLevelValue').textContent = state.level;
  document.getElementById('gameGoldValue').textContent = state.gold;
  document.getElementById('gameDiamondValue').textContent = state.diamonds;
  document.getElementById('rankName').textContent = currentRankText();
  renderSelectedHero();
  const durationLabel=document.getElementById('startGameDuration');
  if(durationLabel) durationLabel.textContent=Number(state.gameRules?.matchMinutes)||30;
  const pct = Math.max(0, Math.min(100, (state.xp/state.xpMax)*100));
  document.getElementById('xpFill').style.width = pct + '%';
}

function renderSelectedHero(){
  const hero = HEROES[state.selectedHero] || HEROES.young_stylish;
  const heroFigure = document.getElementById('heroFigure');
  const styleClass={
    style_gold_aura:'style-gold-aura',
    style_crown:'style-crown',
    style_blue_aura:'style-blue-aura',
    style_dark_armor:'style-dark-armor'
  }[state.equippedStyle]||'';
  heroFigure.className = `hero-figure ${hero.className} ${styleClass}`.trim();
  document.getElementById('selectedHeroName').textContent = hero.name;
  document.getElementById('selectedHeroTrait').textContent = hero.trait;

  document.querySelectorAll('.hero-option').forEach(option=>{
    option.classList.toggle('selected', option.dataset.hero === state.selectedHero);
  });
}

function openHeroPicker(){
  const picker = document.getElementById('heroPicker');
  picker.classList.add('active');
  picker.setAttribute('aria-hidden','false');

  const selectedOption = document.querySelector(`.hero-option[data-hero="${state.selectedHero}"]`);
  const gender = selectedOption?.dataset.gender || 'male';
  setGenderTab(gender);
}

function closeHeroPicker(){
  const picker = document.getElementById('heroPicker');
  picker.classList.remove('active');
  picker.setAttribute('aria-hidden','true');
}

function setGenderTab(gender){
  document.querySelectorAll('.gender-tab').forEach(tab=>{
    tab.classList.toggle('active', tab.dataset.gender === gender);
  });
  document.querySelectorAll('.hero-option').forEach(option=>{
    option.classList.toggle('hidden', option.dataset.gender !== gender);
  });
}

function selectHero(heroId){
  if(!HEROES[heroId]) return;
  state.selectedHero = heroId;
  saveState();
  renderSelectedHero();
  showToast(`${HEROES[heroId].name} انتخاب شد`);
  setTimeout(closeHeroPicker, 450);
}


function difficultyLabel(value){
  return value === 'hard' ? 'سخت' : value === 'easy' ? 'آسان' : 'متوسط';
}

function escapeHtml(value=''){
  return String(value)
    .replaceAll('&','&amp;')
    .replaceAll('<','&lt;')
    .replaceAll('>','&gt;')
    .replaceAll('"','&quot;')
    .replaceAll("'","&#039;");
}

function renderTaskCategoryFilter(){
  const select = document.getElementById('taskCategoryFilter');
  if(!select) return;
  const current = select.value || 'all';
  const categories = [...new Set(state.tasks.map(t=>(t.category||'بدون دسته').trim()).filter(Boolean))].sort();
  select.innerHTML = '<option value="all">همه دسته‌ها</option>' +
    categories.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
  if([...select.options].some(o=>o.value===current)) select.value = current;
}

function renderTasks(){
  refreshTaskCategoryUI();
  const list = document.getElementById('taskList');
  if(!list) return;

  renderTaskCategoryFilter();

  const q = (document.getElementById('taskSearchInput')?.value || '').trim().toLowerCase();
  const category = document.getElementById('taskCategoryFilter')?.value || 'all';

  const filtered = state.tasks.filter(task=>{
    const hay = `${task.name} ${task.category} ${task.note||''}`.toLowerCase();
    return (!q || hay.includes(q)) && (category === 'all' || task.category === category);
  });

  document.getElementById('taskCountAll').textContent = state.tasks.length;
  document.getElementById('taskCountActive').textContent = state.tasks.filter(t=>t.active).length;
  document.getElementById('taskCountInactive').textContent = state.tasks.filter(t=>!t.active).length;

  const empty = document.getElementById('taskEmptyState');
  empty.classList.toggle('hidden', filtered.length > 0);

  list.innerHTML = filtered.map(task=>`
    <article class="task-card ${task.active ? '' : 'inactive'}">
      <div class="task-main">
        <h3>${escapeHtml(task.name)}</h3>
        <div class="task-meta">
          <span class="badge category">${escapeHtml(task.category || 'بدون دسته')}</span>
          <span class="badge ${task.difficulty}">${difficultyLabel(task.difficulty)}</span>
        </div>
        <div class="task-rewards">
          <span class="xp">⭐ ${Number(task.xp)||0} XP</span>
          <span class="gold">🪙 ${Number(task.gold)||0}</span>
          <span class="diamond">💎 ${Number(task.diamonds)||0}</span>
        </div>
        ${task.note ? `<div class="task-note">${escapeHtml(task.note)}</div>` : ''}
      </div>
      <div class="task-actions">
        <button title="فعال/غیرفعال" data-action="toggle" data-id="${task.id}">${task.active ? '◉' : '○'}</button>
        <button title="ویرایش" data-action="edit" data-id="${task.id}">✎</button>
        <button class="delete" title="حذف" data-action="delete" data-id="${task.id}">🗑</button>
      </div>
      <div class="task-active-dot ${task.active ? '' : 'off'}">${task.active ? '● فعال در بازی' : '● غیرفعال'}</div>
    </article>
  `).join('');
}

function openTaskEditor(taskId=null){
  const editor = document.getElementById('taskEditor');
  const task = taskId ? state.tasks.find(t=>t.id===taskId) : null;

  document.getElementById('taskEditorTitle').textContent = task ? 'ویرایش کار' : 'افزودن کار';
  document.getElementById('taskIdInput').value = task?.id || '';
  document.getElementById('taskNameInput').value = task?.name || '';
  document.getElementById('taskCategoryInput').value = task?.category || '';
  document.getElementById('taskDifficultyInput').value = task?.difficulty || 'medium';
  document.getElementById('taskXpInput').value = task?.xp ?? 20;
  document.getElementById('taskGoldInput').value = task?.gold ?? 20;
  document.getElementById('taskDiamondInput').value = task?.diamonds ?? 0;
  document.getElementById('taskActiveInput').checked = task?.active ?? true;
  document.getElementById('taskNoteInput').value = task?.note || '';

  editor.classList.add('active');
  editor.setAttribute('aria-hidden','false');
  setTimeout(()=>document.getElementById('taskNameInput').focus(), 80);
}

function closeTaskEditor(){
  const editor = document.getElementById('taskEditor');
  editor.classList.remove('active');
  editor.setAttribute('aria-hidden','true');
}

function saveTaskFromForm(event){
  event.preventDefault();
  const id = document.getElementById('taskIdInput').value;
  const name = document.getElementById('taskNameInput').value.trim();
  if(!name) return;

  const taskData = {
    id: id || `task_${Date.now()}`,
    name,
    category: document.getElementById('taskCategoryInput').value.trim() || 'بدون دسته',
    difficulty: document.getElementById('taskDifficultyInput').value,
    xp: Math.max(0, Number(document.getElementById('taskXpInput').value) || 0),
    gold: Math.max(0, Number(document.getElementById('taskGoldInput').value) || 0),
    diamonds: Math.max(0, Number(document.getElementById('taskDiamondInput').value) || 0),
    active: document.getElementById('taskActiveInput').checked,
    note: document.getElementById('taskNoteInput').value.trim()
  };

  if(id){
    const idx = state.tasks.findIndex(t=>t.id===id);
    if(idx >= 0) state.tasks[idx] = taskData;
  }else{
    state.tasks.unshift(taskData);
  }

  saveState();
  renderTasks();
  closeTaskEditor();
  showToast(id ? 'کار ویرایش شد' : 'کار جدید اضافه شد');
}

function handleTaskAction(event){
  const button = event.target.closest('button[data-action]');
  if(!button) return;
  const id = button.dataset.id;
  const action = button.dataset.action;
  const task = state.tasks.find(t=>t.id===id);
  if(!task) return;

  if(action === 'edit'){
    openTaskEditor(id);
    return;
  }
  if(action === 'toggle'){
    task.active = !task.active;
    saveState();
    renderTasks();
    showToast(task.active ? 'کار وارد بازی شد' : 'کار از بازی غیرفعال شد');
    return;
  }
  if(action === 'delete'){
    const ok = confirm(`«${task.name}» حذف شود؟`);
    if(!ok) return;
    state.tasks = state.tasks.filter(t=>t.id!==id);
    saveState();
    renderTasks();
    showToast('کار حذف شد');
  }
}



function laneKeyLabel(lane){
  return lane === 'top' ? 'بالا' : lane === 'mid' ? 'وسط' : 'پایین';
}

function isEntityLocked(entity){
  if(entity.type === 'tower' && entity.stage === 2){
    return (MOBA.laneProgress[entity.lane] || 0) < 1;
  }
  if(entity.type === 'base'){
    return !Object.values(MOBA.laneProgress).some(v=>v >= 2);
  }
  return false;
}

function renderLaneProgress(){
  const config = {
    top:['laneTopProgress','laneTopStage'],
    mid:['laneMidProgress','laneMidStage'],
    bot:['laneBotProgress','laneBotStage']
  };

  Object.entries(config).forEach(([lane, ids])=>{
    const progress = MOBA.laneProgress[lane] || 0;
    const pct = progress >= 2 ? 100 : progress === 1 ? 50 : 0;
    const bar = document.getElementById(ids[0]);
    const label = document.getElementById(ids[1]);
    if(bar) bar.style.width = `${pct}%`;
    if(label) label.textContent = `${Math.min(progress,2)}/2`;
  });

  MAP_ENTITIES.filter(e=>e.type==='tower' && e.stage===2).forEach(entity=>{
    const node = document.querySelector(`[data-id="${entity.id}"]`);
    if(!node) return;
    const locked = isEntityLocked(entity);
    node.classList.toggle('locked', locked);
  });

  const baseEntity = MAP_ENTITIES.find(e=>e.type==='base');
  const baseNode = document.querySelector('[data-id="enemy_base"]');
  if(baseEntity && baseNode){
    baseNode.classList.toggle('locked', isEntityLocked(baseEntity));
  }
}

function showWaveBanner(){
  const banner = document.getElementById('waveBanner');
  if(!banner) return;
  banner.textContent = `Wave ${MOBA.wave} وارد شد!`;
  banner.classList.remove('show');
  void banner.offsetWidth;
  banner.classList.add('show');
}

function respawnMinions(){
  document.querySelectorAll('.minion-node').forEach(node=>{
    node.classList.remove('defeated','hit','respawning');
    node.style.opacity = '1';
    node.style.transform = 'translate(-50%,-50%)';
  });
  showWaveBanner();
}

function startWaveSystem(){
  clearInterval(MOBA.waveInterval);
  MOBA.wave = 1;
  MOBA.waveDuration = Number(state.gameRules?.waveSeconds)||45;
  MOBA.waveRemaining = MOBA.waveDuration;
  document.getElementById('waveNumber').textContent = MOBA.wave;
  document.getElementById('waveCountdown').textContent = formatElapsed(MOBA.waveRemaining);

  MOBA.waveInterval = setInterval(()=>{
    MOBA.waveRemaining -= 1;
    if(MOBA.waveRemaining <= 0){
      MOBA.wave += 1;
      MOBA.waveRemaining = MOBA.waveDuration;
      document.getElementById('waveNumber').textContent = MOBA.wave;
      respawnMinions();
    }
    document.getElementById('waveCountdown').textContent = formatElapsed(MOBA.waveRemaining);
  },1000);
}

function stopWaveSystem(){
  clearInterval(MOBA.waveInterval);
  MOBA.waveInterval = null;
}

function resetMobaHero(){
  MOBA.x = 22;
  MOBA.y = 80;
  MOBA.vx = 0;
  MOBA.vy = 0;
  updateHeroPosition();
}

function updateHeroPosition(){
  const hero = document.getElementById('playerHero');
  if(!hero) return;
  hero.style.left = `${MOBA.x}%`;
  hero.style.top = `${MOBA.y}%`;
}

function getActiveTasks(){
  return state.tasks.filter(t=>t.active);
}

function pickTaskForEncounter(){
  const tasks = getActiveTasks();
  if(!tasks.length) return null;

  // Tasks marked "later" stay out for several encounters, then naturally return.
  const allowed = tasks.filter(t=>!MOBA.deferredTaskIds.includes(t.id));
  const pool = allowed.length ? allowed : tasks;

  return pool[Math.floor(Math.random()*pool.length)];
}

function distancePercent(ax, ay, bx, by){
  return Math.hypot(ax-bx, ay-by);
}

function updateNearbyEntity(){
  if(Date.now() < MOBA.entityCooldownUntil) return;

  let best = null;
  let bestDist = Infinity;
  for(const entity of MAP_ENTITIES){
    const node = document.querySelector(`[data-id="${entity.id}"]`);
    if(node?.classList.contains('defeated')) continue;
    if(isEntityLocked(entity)) continue;
    const dist = distancePercent(MOBA.x, MOBA.y, entity.x, entity.y);
    if(dist < bestDist){
      bestDist = dist;
      best = entity;
    }
  }

  const threshold = best?.type === 'tower' ? 9 : best?.type === 'base' ? 10 : 7;
  if(best && bestDist <= threshold){
    if(MOBA.nearby?.id !== best.id){
      MOBA.nearby = best;
      openEncounter(best);
    }
  }else{
    MOBA.nearby = null;
  }
}

function openEncounter(entity){
  const task = pickTaskForEncounter();
  const panel = document.getElementById('encounterPanel');
  const hint = document.getElementById('interactionHint');
  MOBA.encounterTask = task;
  MOBA.encounteredEntity = entity;

  document.getElementById('encounterType').textContent =
    entity.type === 'tower'
      ? `تاور ${entity.stage || 1} • لاین ${laneKeyLabel(entity.lane)}`
      : `مینیون • لاین ${laneKeyLabel(entity.lane)}`;
  document.getElementById('encounterTitle').textContent =
    entity.type === 'tower' ? 'برای ضربه زدن به تاور یک کار انجام بده' : 'برای شکست این مینیون یک کار انجام بده';

  if(!task){
    document.getElementById('encounterTaskName').textContent = 'هیچ کار فعالی نداری. از بخش «کارها» یک کار را فعال کن.';
    document.getElementById('encounterRewards').innerHTML = '';
    document.getElementById('startEncounterTaskButton').disabled = true;
  }else{
    document.getElementById('encounterTaskName').textContent = task.name;
    document.getElementById('encounterRewards').innerHTML =
      `<span>⭐ ${task.xp} XP</span><span>🪙 ${task.gold}</span><span>💎 ${task.diamonds}</span>`;
    document.getElementById('startEncounterTaskButton').disabled = false;
  }

  panel.classList.add('active');
  panel.setAttribute('aria-hidden','false');
  hint.textContent = entity.type === 'tower' ? 'به تاور رسیدی' : 'به مینیون رسیدی';
  stopJoystickMotion();
}

function closeEncounter(setCooldown=true){
  clearInterval(MOBA.battleTimerInterval);
  MOBA.battleTimerInterval = null;
  MOBA.battleStartedAt = null;

  const readyState = document.getElementById('encounterReadyState');
  const battleState = document.getElementById('battleTaskState');
  readyState?.classList.remove('hidden');
  battleState?.classList.add('hidden');

  const panel = document.getElementById('encounterPanel');
  panel.classList.remove('active');
  panel.setAttribute('aria-hidden','true');
  if(setCooldown) MOBA.entityCooldownUntil = Date.now() + 1200;
  MOBA.nearby = null;
  MOBA.encounterTask = null;
  MOBA.encounteredEntity = null;
  document.getElementById('interactionHint').textContent = 'با جوی‌استیک حرکت کن و به مینیون یا تاور نزدیک شو';
}

function formatElapsed(seconds){
  const m = Math.floor(seconds/60).toString().padStart(2,'0');
  const s = Math.floor(seconds%60).toString().padStart(2,'0');
  return `${m}:${s}`;
}

function startEncounterTask(){
  const task = MOBA.encounterTask;
  const entity = MOBA.encounteredEntity;
  if(!task || !entity) return;

  document.getElementById('encounterReadyState').classList.add('hidden');
  document.getElementById('battleTaskState').classList.remove('hidden');
  document.getElementById('battleTaskName').textContent = task.name;
  document.getElementById('battleTargetLabel').textContent =
    entity.type === 'tower'
      ? 'در حال حمله به تاور'
      : entity.type === 'base'
        ? 'در حال حمله به بیس دشمن'
        : 'در حال مبارزه با مینیون';

  const note = document.getElementById('battleTaskNote');
  note.textContent = task.note || `پاداش: ${task.xp} XP • ${task.gold} طلا • ${task.diamonds} الماس`;
  note.style.display = 'block';

  MOBA.battleStartedAt = Date.now();
  document.getElementById('battleElapsedTimer').textContent = '00:00';

  clearInterval(MOBA.battleTimerInterval);
  MOBA.battleTimerInterval = setInterval(()=>{
    if(!MOBA.battleStartedAt) return;
    const elapsed = (Date.now() - MOBA.battleStartedAt)/1000;
    document.getElementById('battleElapsedTimer').textContent = formatElapsed(elapsed);
  }, 1000);
}

function resetBattleTaskUI(){
  clearInterval(MOBA.battleTimerInterval);
  MOBA.battleTimerInterval = null;
  MOBA.battleStartedAt = null;

  const ready = document.getElementById('encounterReadyState');
  const battle = document.getElementById('battleTaskState');
  if(ready) ready.classList.remove('hidden');
  if(battle) battle.classList.add('hidden');
  const elapsed = document.getElementById('battleElapsedTimer');
  if(elapsed) elapsed.textContent = '00:00';
}

function animateBattleHit(entity, task){
  const hero = document.getElementById('playerHero');
  const node = document.querySelector(`[data-id="${entity.id}"]`);
  const flash = document.getElementById('hitFlash');
  const reward = document.getElementById('rewardFly');

  hero?.classList.remove('attack');
  node?.classList.remove('hit');
  flash?.classList.remove('show');
  reward?.classList.remove('show');

  void hero?.offsetWidth;
  hero?.classList.add('attack');
  node?.classList.add('hit');
  flash?.classList.add('show');

  if(reward){
    reward.innerHTML = `+${task.xp} XP &nbsp; 🪙 +${task.gold}${task.diamonds ? ` &nbsp; 💎 +${task.diamonds}` : ''}`;
    reward.classList.add('show');
  }

  setTimeout(()=>{
    hero?.classList.remove('attack');
    node?.classList.remove('hit');
    flash?.classList.remove('show');
    reward?.classList.remove('show');
  }, 1200);
}


function updateMatchStats(task, entity){
  MOBA.matchStats.tasks += 1;
  MOBA.matchStats.xp += Number(task.xp)||0;
  MOBA.matchStats.gold += Number(task.gold)||0;
  MOBA.matchStats.diamonds += Number(task.diamonds)||0;

  if(entity.type === 'minion') MOBA.matchStats.minions += 1;
}

function currentMatchElapsedSeconds(){
  if(!MOBA.matchStartedAt) return 0;
  return Math.max(0, Math.floor((Date.now() - MOBA.matchStartedAt)/1000));
}


function formatLongPlayTime(totalSeconds){
  totalSeconds = Math.max(0, Number(totalSeconds)||0);
  if(totalSeconds < 3600){
    return `${Math.floor(totalSeconds/60)}m`;
  }
  const h = Math.floor(totalSeconds/3600);
  const m = Math.floor((totalSeconds%3600)/60);
  return `${h}h ${m}m`;
}

function matchScore(match){
  return (match.tasks||0)*10 + (match.towers||0)*35 + (match.minions||0)*6 + (match.victory ? 100 : 0);
}

function saveCurrentMatch(victory){
  if(MOBA.resultSaved) return;

  const elapsed = currentMatchElapsedSeconds();
  const record = {
    id: `match_${Date.now()}`,
    date: new Date().toISOString(),
    victory: Boolean(victory),
    duration: elapsed,
    tasks: MOBA.matchStats.tasks,
    minions: MOBA.matchStats.minions,
    towers: MOBA.matchStats.towers,
    xp: MOBA.matchStats.xp,
    gold: MOBA.matchStats.gold,
    diamonds: MOBA.matchStats.diamonds,
    wave: MOBA.wave
  };

  state.matchHistory.unshift(record);
  state.matchHistory = state.matchHistory.slice(0, 100);

  state.lifetimeStats.matches += 1;
  if(victory) state.lifetimeStats.wins += 1;
  state.lifetimeStats.playSeconds += elapsed;
  state.lifetimeStats.tasks += record.tasks;
  state.lifetimeStats.minions += record.minions;
  state.lifetimeStats.towers += record.towers;
  state.lifetimeStats.xp += record.xp;
  state.lifetimeStats.gold += record.gold;
  state.lifetimeStats.diamonds += record.diamonds;

  MOBA.resultSaved = true;
  saveState();
  renderGameStats();
}

function renderGameStats(){
  const s = state.lifetimeStats || defaultState.lifetimeStats;
  const history = state.matchHistory || [];

  const set = (id, value)=>{
    const el = document.getElementById(id);
    if(el) el.textContent = value;
  };

  set('statsTotalMatches', s.matches || 0);
  set('statsWins', s.wins || 0);
  set('statsPlayTime', formatLongPlayTime(s.playSeconds || 0));
  set('statsTasksDone', s.tasks || 0);
  set('statsMinions', s.minions || 0);
  set('statsTowers', s.towers || 0);

  const best = history.length
    ? [...history].sort((a,b)=>matchScore(b)-matchScore(a))[0]
    : null;

  set('bestMatchLabel', best ? (best.victory ? 'Victory' : 'بهترین رکورد زمانی') : 'هنوز ثبت نشده');
  set('bestMatchTasks', best?.tasks || 0);
  set('bestMatchXp', best?.xp || 0);
  set('bestMatchGold', best?.gold || 0);
  set('bestMatchTime', best ? formatElapsed(best.duration || 0) : '00:00');

  const list = document.getElementById('matchHistoryList');
  const empty = document.getElementById('matchHistoryEmpty');
  if(!list || !empty) return;

  empty.classList.toggle('hidden', history.length > 0);

  list.innerHTML = history.slice(0,30).map(match=>{
    const date = new Date(match.date);
    const dateText = Number.isNaN(date.getTime())
      ? ''
      : date.toLocaleDateString('fa-IR', {month:'short', day:'numeric'});

    return `
      <article class="history-card ${match.victory ? 'win' : ''}">
        <div class="history-card-head">
          <div class="history-result">
            <span class="result-icon">${match.victory ? '🏆' : '⏱'}</span>
            <div>
              <strong>${match.victory ? 'پیروزی' : 'پایان زمان'}</strong>
              <small>${dateText} • Wave ${match.wave || 1}</small>
            </div>
          </div>
          <span class="history-time">${formatElapsed(match.duration || 0)}</span>
        </div>
        <div class="history-numbers">
          <div><small>کار</small><b>${match.tasks || 0}</b></div>
          <div><small>Minion</small><b>${match.minions || 0}</b></div>
          <div><small>Tower</small><b>${match.towers || 0}</b></div>
          <div><small>XP</small><b>${match.xp || 0}</b></div>
          <div><small>Gold</small><b>${match.gold || 0}</b></div>
          <div><small>Diamond</small><b>${match.diamonds || 0}</b></div>
        </div>
      </article>
    `;
  }).join('');
}


function formatCompactNumber(value){
  const n = Number(value)||0;
  if(n >= 1000000000) return `${(n/1000000000).toFixed(n%1000000000 ? 1 : 0)}B`;
  if(n >= 1000000) return `${(n/1000000).toFixed(n%1000000 ? 1 : 0)}M`;
  if(n >= 1000) return `${(n/1000).toFixed(n%1000 ? 1 : 0)}K`;
  return String(n);
}

function pct(current, goal){
  current = Number(current)||0;
  goal = Number(goal)||0;
  if(goal <= 0) return 0;
  return Math.max(0, Math.min(100, Math.round(current/goal*100)));
}

function statusLabel(status){
  return status === 'active' ? 'فعال' : status === 'watch' ? 'پیگیری' : 'غیرفعال';
}

function parentName(parentId){
  if(!parentId) return 'مستقیم من';
  return state.teamMembers.find(m=>m.id===parentId)?.name || 'نامشخص';
}

function teamDescendantIds(memberId,seen=new Set()){
  if(!memberId||seen.has(memberId))return seen;
  seen.add(memberId);
  state.teamMembers.filter(m=>m.parentId===memberId).forEach(m=>teamDescendantIds(m.id,seen));
  return seen;
}
function renderTeamParentOptions(excludeId=''){
  const select = document.getElementById('teamMemberParentInput');
  if(!select) return;
  const blocked=excludeId?teamDescendantIds(excludeId):new Set();
  select.innerHTML = '<option value="">مستقیم من</option>' +
    state.teamMembers
      .filter(m=>m.id!==excludeId&&!blocked.has(m.id))
      .map(m=>`<option value="${m.id}">${escapeHtml(m.name)}</option>`).join('');
}

function renderTeamStats(){
  const members = state.teamMembers || [];
  const goals = state.teamGoals || defaultState.teamGoals;
  const totalSales = members.reduce((s,m)=>s+(Number(m.sales)||0),0);
  const totalGpv = members.reduce((s,m)=>s+(Number(m.gpv)||0),0);
  const totalPeople = members.reduce((s,m)=>s+(Number(m.people)||0),0);

  const set=(id,value)=>{const el=document.getElementById(id); if(el) el.textContent=value;};

  set('teamMembersCount', members.length);
  set('teamSalesTotal', formatCompactNumber(totalSales));
  set('teamGpvTotal', formatCompactNumber(totalGpv));
  set('teamPeopleGoalProgress', `${pct(totalPeople,goals.people)}%`);

  set('teamGoalPeopleText', `${formatCompactNumber(totalPeople)} / ${formatCompactNumber(goals.people)}`);
  set('teamGoalSalesText', `${formatCompactNumber(totalSales)} / ${formatCompactNumber(goals.sales)}`);
  set('teamGoalGpvText', `${formatCompactNumber(totalGpv)} / ${formatCompactNumber(goals.gpv)}`);

  document.getElementById('teamGoalPeopleBar').style.width = `${pct(totalPeople,goals.people)}%`;
  document.getElementById('teamGoalSalesBar').style.width = `${pct(totalSales,goals.sales)}%`;
  document.getElementById('teamGoalGpvBar').style.width = `${pct(totalGpv,goals.gpv)}%`;

  renderNetworkTree();
  renderTeamMemberList();
  renderTeamActionLeaderboard();
}
function buildTreeRows(parentId='', depth=0, seen=new Set()){
  const children = state.teamMembers.filter(m=>(m.parentId||'')===parentId);
  const rows = [];
  children.forEach(member=>{
    if(seen.has(member.id)) return;
    const nextSeen = new Set(seen);
    nextSeen.add(member.id);
    rows.push({member, depth});
    rows.push(...buildTreeRows(member.id, depth+1, nextSeen));
  });
  return rows;
}

function renderNetworkTree(){
  const tree = document.getElementById('networkTree');
  if(!tree) return;
  const rows = buildTreeRows();
  if(!rows.length){
    tree.innerHTML = '<div class="task-note">با افزودن اعضا و مشخص کردن «معرف»، درخت شبکه اینجا ساخته می‌شود.</div>';
    return;
  }

  tree.innerHTML = rows.map(({member,depth})=>`
    <div class="tree-row">
      <div class="tree-indent" style="--depth:${depth}"></div>
      ${depth ? '<div class="tree-branch"></div>' : ''}
      <div class="tree-person">
        <div class="tree-person-main">
          <div class="tree-avatar">${escapeHtml((member.name||'?').trim().charAt(0) || '?')}</div>
          <div>
            <strong>${escapeHtml(member.name)}</strong>
            <small>${depth ? `زیرمجموعه ${escapeHtml(parentName(member.parentId))}` : 'شاخه مستقیم'}</small>
          </div>
        </div>
        <span class="tree-status ${member.status}">${statusLabel(member.status)}</span>
      </div>
    </div>
  `).join('');
}

function renderTeamMemberList(){
  const list = document.getElementById('teamMemberList');
  const empty = document.getElementById('teamEmptyState');
  if(!list || !empty) return;

  const q = (document.getElementById('teamSearchInput')?.value || '').trim().toLowerCase();
  const members = state.teamMembers.filter(m=>
    !q || `${m.name} ${parentName(m.parentId)} ${m.note||''}`.toLowerCase().includes(q)
  );

  empty.classList.toggle('hidden', members.length > 0);

  list.innerHTML = members.map(member=>{
    const salesPct = pct(member.sales, member.salesGoal);
    const gpvPct = pct(member.gpv, member.gpvGoal);
    const peoplePct = pct(member.people, member.peopleGoal);

    return `
      <article class="member-card">
        <div class="member-card-head">
          <div class="member-name-wrap">
            <strong>${escapeHtml(member.name)}</strong>
            <small>${escapeHtml(parentName(member.parentId))} • ${statusLabel(member.status)} • رشد هدف ${Number(member.growth)||0}%</small>
          </div>
          <div class="member-actions">
            <button data-team-action="edit" data-id="${member.id}">✎</button>
            <button class="delete" data-team-action="delete" data-id="${member.id}">🗑</button>
          </div>
        </div>

        <div class="member-metrics">
          <div class="member-metric"><span>فروش</span><b>${formatCompactNumber(member.sales)}</b></div>
          <div class="member-metric"><span>GPV</span><b>${formatCompactNumber(member.gpv)}</b></div>
          <div class="member-metric"><span>نفرات</span><b>${Number(member.people)||0}</b></div>
        </div>

        <div class="member-progress-grid">
          <div class="member-progress-box">
            <small>هدف فروش</small><strong>${salesPct}%</strong>
            <div class="member-mini-track"><i style="width:${salesPct}%"></i></div>
          </div>
          <div class="member-progress-box">
            <small>هدف GPV</small><strong>${gpvPct}%</strong>
            <div class="member-mini-track"><i style="width:${gpvPct}%"></i></div>
          </div>
          <div class="member-progress-box">
            <small>هدف نفرات</small><strong>${peoplePct}%</strong>
            <div class="member-mini-track"><i style="width:${peoplePct}%"></i></div>
          </div>
        </div>

        ${member.note ? `<div class="member-note">${escapeHtml(member.note)}</div>` : ''}
      </article>
    `;
  }).join('');
}

function openTeamMemberEditor(id=''){
  const editor = document.getElementById('teamMemberEditor');
  const member = id ? state.teamMembers.find(m=>m.id===id) : null;
  renderTeamParentOptions(id);

  document.getElementById('teamMemberEditorTitle').textContent = member ? 'ویرایش عضو' : 'افزودن عضو';
  document.getElementById('teamMemberIdInput').value = member?.id || '';
  document.getElementById('teamMemberNameInput').value = member?.name || '';
  document.getElementById('teamMemberParentInput').value = member?.parentId || '';
  document.getElementById('teamMemberStatusInput').value = member?.status || 'active';
  document.getElementById('teamMemberSalesInput').value = member?.sales ?? 0;
  document.getElementById('teamMemberSalesGoalInput').value = member?.salesGoal ?? 0;
  document.getElementById('teamMemberGpvInput').value = member?.gpv ?? 0;
  document.getElementById('teamMemberGpvGoalInput').value = member?.gpvGoal ?? 0;
  document.getElementById('teamMemberPeopleInput').value = member?.people ?? 0;
  document.getElementById('teamMemberPeopleGoalInput').value = member?.peopleGoal ?? 0;
  document.getElementById('teamMemberGrowthInput').value = member?.growth ?? 0;
  document.getElementById('teamMemberNoteInput').value = member?.note || '';

  editor.classList.add('active');
  editor.setAttribute('aria-hidden','false');
}

function closeTeamMemberEditor(){
  const editor = document.getElementById('teamMemberEditor');
  editor.classList.remove('active');
  editor.setAttribute('aria-hidden','true');
}

function saveTeamMember(event){
  event.preventDefault();
  const id = document.getElementById('teamMemberIdInput').value;
  const name = document.getElementById('teamMemberNameInput').value.trim();
  if(!name) return;

  const member = {
    id: id || `member_${Date.now()}`,
    name,
    parentId: document.getElementById('teamMemberParentInput').value,
    status: document.getElementById('teamMemberStatusInput').value,
    sales: Math.max(0, Number(document.getElementById('teamMemberSalesInput').value)||0),
    salesGoal: Math.max(0, Number(document.getElementById('teamMemberSalesGoalInput').value)||0),
    gpv: Math.max(0, Number(document.getElementById('teamMemberGpvInput').value)||0),
    gpvGoal: Math.max(0, Number(document.getElementById('teamMemberGpvGoalInput').value)||0),
    people: Math.max(0, Number(document.getElementById('teamMemberPeopleInput').value)||0),
    peopleGoal: Math.max(0, Number(document.getElementById('teamMemberPeopleGoalInput').value)||0),
    growth: Math.max(0, Number(document.getElementById('teamMemberGrowthInput').value)||0),
    note: document.getElementById('teamMemberNoteInput').value.trim()
  };

  if(id){
    const idx = state.teamMembers.findIndex(m=>m.id===id);
    if(idx>=0) state.teamMembers[idx] = member;
  }else{
    state.teamMembers.unshift(member);
  }

  saveState();
  renderTeamStats();
  closeTeamMemberEditor();
  showToast(id ? 'اطلاعات عضو ویرایش شد' : 'عضو جدید اضافه شد');
}

function handleTeamMemberAction(event){
  const btn = event.target.closest('[data-team-action]');
  if(!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.teamAction;
  const member = state.teamMembers.find(m=>m.id===id);
  if(!member) return;

  if(action==='edit'){
    openTeamMemberEditor(id);
    return;
  }

  if(action==='delete'){
    const hasChildren = state.teamMembers.some(m=>m.parentId===id);
    const msg = hasChildren
      ? `«${member.name}» زیرمجموعه دارد. با حذف او، زیرمجموعه‌های مستقیمش به شاخه مستقیم منتقل شوند؟`
      : `«${member.name}» حذف شود؟`;
    if(!confirm(msg)) return;

    state.teamMembers.forEach(m=>{
      if(m.parentId===id) m.parentId = '';
    });
    state.teamMembers = state.teamMembers.filter(m=>m.id!==id);
    saveState();
    renderTeamStats();
    showToast('عضو حذف شد');
  }
}

function openTeamGoalsEditor(){
  const g = state.teamGoals;
  document.getElementById('teamGoalPeopleInput').value = g.people || 0;
  document.getElementById('teamGoalSalesInput').value = g.sales || 0;
  document.getElementById('teamGoalGpvInput').value = g.gpv || 0;
  document.getElementById('teamGoalGrowthInput').value = g.growth || 0;
  const editor = document.getElementById('teamGoalsEditor');
  editor.classList.add('active');
  editor.setAttribute('aria-hidden','false');
}

function closeTeamGoalsEditor(){
  const editor = document.getElementById('teamGoalsEditor');
  editor.classList.remove('active');
  editor.setAttribute('aria-hidden','true');
}

function saveTeamGoals(event){
  event.preventDefault();
  state.teamGoals = {
    people: Math.max(0, Number(document.getElementById('teamGoalPeopleInput').value)||0),
    sales: Math.max(0, Number(document.getElementById('teamGoalSalesInput').value)||0),
    gpv: Math.max(0, Number(document.getElementById('teamGoalGpvInput').value)||0),
    growth: Math.max(0, Number(document.getElementById('teamGoalGrowthInput').value)||0)
  };
  saveState();
  renderTeamStats();
  closeTeamGoalsEditor();
  showToast('اهداف تیم ذخیره شد');
}

function setStatsTab(tab){
  document.querySelectorAll('.stats-tab').forEach(btn=>{
    btn.classList.toggle('active', btn.dataset.statsTab === tab);
  });
  document.getElementById('gameStatsPanel').classList.toggle('active', tab === 'game');
  document.getElementById('teamStatsPanel').classList.toggle('active', tab === 'team');
  if(tab === 'game') renderGameStats();
  if(tab === 'team') renderTeamStats();
}

function clearMatchHistory(){
  if(!state.matchHistory.length) return;
  const ok = confirm('تاریخچه همه Matchها پاک شود؟');
  if(!ok) return;

  state.matchHistory = [];
  state.lifetimeStats = {
    matches:0,wins:0,playSeconds:0,tasks:0,minions:0,towers:0,xp:0,gold:0,diamonds:0
  };
  saveState();
  renderGameStats();
  showToast('تاریخچه بازی‌ها پاک شد');
}

function showMatchResult(victory=true, reason=''){
  saveCurrentMatch(victory);
  clearInterval(timerInterval);
  stopWaveSystem();
  stopMobaLoop();
  closeEncounter(false);

  const overlay = document.getElementById('matchResult');
  overlay.classList.add('active');
  overlay.setAttribute('aria-hidden','false');

  document.getElementById('resultCrown').textContent = victory ? '🏆' : '⏱';
  document.getElementById('resultTitle').textContent = victory ? 'پیروزی' : 'پایان بازی';
  document.getElementById('resultSubtitle').textContent =
    reason || (victory ? 'بیس دشمن نابود شد.' : 'زمان ۳۰ دقیقه‌ای تمام شد.');

  document.getElementById('resultTasks').textContent = MOBA.matchStats.tasks;
  document.getElementById('resultMinions').textContent = MOBA.matchStats.minions;
  document.getElementById('resultTowers').textContent = MOBA.matchStats.towers;
  document.getElementById('resultTime').textContent = formatElapsed(currentMatchElapsedSeconds());
  document.getElementById('resultXp').textContent = MOBA.matchStats.xp;
  document.getElementById('resultGold').textContent = MOBA.matchStats.gold;
  document.getElementById('resultDiamonds').textContent = MOBA.matchStats.diamonds;
  document.getElementById('resultRankName').textContent = currentRankText();

  const laneScore = Object.values(MOBA.laneProgress).reduce((a,b)=>a+b,0);
  const rankProgress = Math.min(100, 54 + MOBA.matchStats.tasks*2 + laneScore*4 + (victory ? 12 : 0));
  document.getElementById('resultRankFill').style.width = `${rankProgress}%`;
  document.getElementById('resultRankText').textContent = `${rankProgress} / 100`;
}

function closeMatchResultToHome(){
  const overlay = document.getElementById('matchResult');
  overlay.classList.remove('active');
  overlay.setAttribute('aria-hidden','true');
  document.getElementById('gamePage').classList.remove('active');
  document.getElementById('gamePage').setAttribute('aria-hidden','true');
  document.getElementById('bottomNav').style.display = 'grid';
  bootToHome();
}

function completeBattleTask(){
  const task = MOBA.encounterTask;
  const entity = MOBA.encounteredEntity;
  if(!task || !entity) return;

  clearInterval(MOBA.battleTimerInterval);

  state.xp += Number(task.xp)||0;
  state.gold += Number(task.gold)||0;
  state.diamonds += Number(task.diamonds)||0;
  updateMatchStats(task, entity);

  while(state.xp >= state.xpMax){
    state.xp -= state.xpMax;
    state.level += 1;
    state.xpMax = Math.round(state.xpMax * (1 + (Number(state.gameRules?.xpGrowthPercent)||16)/100));
  }

  animateBattleHit(entity, task);

  const node = document.querySelector(`[data-id="${entity.id}"]`);
  let resultMessage = '';

  if(entity.type === 'minion'){
    resultMessage = 'مینیون شکست خورد!';
    setTimeout(()=>{
      node?.classList.add('defeated');
      if(node){
        node.style.opacity = '0';
        node.style.transform = 'translate(-50%,-50%) scale(.2)';
      }
    }, 300);

  }else if(entity.type === 'tower'){
    const hp = node?.querySelector('.tower-hp i');
    if(hp){
      const maxHp=Number(state.gameRules?.towerHp)||100;
      const current=Number(hp.dataset.hp||maxHp);
      const next=Math.max(0,current-(Number(state.gameRules?.towerDamage)||34));
      hp.dataset.hp=String(next);
      hp.style.width=`${Math.max(0,Math.min(100,(next/maxHp)*100))}%`;

      if(next <= 0){
        MOBA.laneProgress[entity.lane] = Math.max(MOBA.laneProgress[entity.lane] || 0, entity.stage || 1);
        MOBA.matchStats.towers += 1;
        renderLaneProgress();

        resultMessage =
          (entity.stage || 1) === 1
            ? `تاور اول لاین ${laneKeyLabel(entity.lane)} نابود شد؛ تاور دوم باز شد!`
            : `لاین ${laneKeyLabel(entity.lane)} کامل فتح شد و بیس دشمن قابل حمله است!`;

        setTimeout(()=>{
          node.classList.add('defeated');
          node.style.opacity = '.28';
        }, 350);
      }else{
        resultMessage = `ضربه به تاور! ${next} HP باقی مانده`;
      }
    }

  }else if(entity.type === 'base'){
    const hp = document.getElementById('enemyBaseHpBar');
    const maxHp=Number(state.gameRules?.baseHp)||100;
    const current=Number(hp?.dataset.hp||MOBA.baseHp||maxHp);
    const next=Math.max(0,current-(Number(state.gameRules?.baseDamage)||25));
    MOBA.baseHp=next;

    if(hp){
      hp.dataset.hp=String(next);
      hp.style.width=`${Math.max(0,Math.min(100,(next/maxHp)*100))}%`;
    }

    if(next <= 0){
      resultMessage = 'بیس دشمن نابود شد!';
      if(node){
        node.classList.add('defeated');
        node.style.opacity = '.25';
      }
    }else{
      resultMessage = `ضربه به بیس! ${next} HP باقی مانده`;
    }
  }

  // Any deferred task gets one step closer to returning after every completed battle.
  if(MOBA.deferredTaskIds.length){
    MOBA.deferredTaskIds.shift();
  }

  saveState();
renderState();

  // Let the hit animation play before closing.
  setTimeout(()=>{
    resetBattleTaskUI();

    if(entity.type === 'base' && MOBA.baseHp <= 0){
      closeEncounter(false);
      showToast(resultMessage);
      setTimeout(()=>showMatchResult(true), 700);
    }else{
      closeEncounter();
      showToast(resultMessage);
    }
  }, 650);
}

function deferBattleTask(){
  const task = MOBA.encounterTask;
  if(task && !MOBA.deferredTaskIds.includes(task.id)){
    MOBA.deferredTaskIds.push(task.id);
  }

  resetBattleTaskUI();
  closeEncounter(true);
  showToast('این کار برای چند هدف بعدی کنار گذاشته شد');
}

function cancelBattleTask(){
  resetBattleTaskUI();
  closeEncounter(true);
  showToast('مبارزه لغو شد');
}

function stopJoystickMotion(){
  MOBA.vx = 0;
  MOBA.vy = 0;
  const knob = document.getElementById('joystickKnob');
  if(knob) knob.style.transform = 'translate(0px,0px)';
}

function setJoystickFromPointer(clientX, clientY){
  const area = document.getElementById('joystickArea');
  const knob = document.getElementById('joystickKnob');
  if(!area || !knob) return;

  const rect = area.getBoundingClientRect();
  const cx = rect.left + rect.width/2;
  const cy = rect.top + rect.height/2;
  let dx = clientX - cx;
  let dy = clientY - cy;
  const max = 40;
  const len = Math.hypot(dx,dy) || 1;
  if(len > max){
    dx = dx/len*max;
    dy = dy/len*max;
  }
  knob.style.transform = `translate(${dx}px,${dy}px)`;
  MOBA.vx = dx/max;
  MOBA.vy = dy/max;
}

function startMobaLoop(){
  cancelAnimationFrame(MOBA.raf);
  MOBA.lastTs = performance.now();

  const tick = (ts)=>{
    const dt = Math.min(32, ts - MOBA.lastTs);
    MOBA.lastTs = ts;

    if(!document.getElementById('encounterPanel').classList.contains('active')){
      MOBA.x += MOBA.vx * MOBA.speed * dt;
      MOBA.y += MOBA.vy * MOBA.speed * dt;
      MOBA.x = Math.max(4, Math.min(96, MOBA.x));
      MOBA.y = Math.max(10, Math.min(94, MOBA.y));
      updateHeroPosition();
      updateNearbyEntity();
    }

    MOBA.raf = requestAnimationFrame(tick);
  };
  MOBA.raf = requestAnimationFrame(tick);
}

function stopMobaLoop(){
  cancelAnimationFrame(MOBA.raf);
  MOBA.raf = null;
  stopJoystickMotion();
}

function setupJoystick(){
  const area = document.getElementById('joystickArea');
  if(!area || area.dataset.ready) return;
  area.dataset.ready = '1';

  const start = e=>{
    e.preventDefault();
    MOBA.joystickActive = true;
    const p = e.touches ? e.touches[0] : e;
    setJoystickFromPointer(p.clientX, p.clientY);
  };
  const move = e=>{
    if(!MOBA.joystickActive) return;
    e.preventDefault();
    const p = e.touches ? e.touches[0] : e;
    setJoystickFromPointer(p.clientX, p.clientY);
  };
  const end = e=>{
    if(!MOBA.joystickActive) return;
    e.preventDefault?.();
    MOBA.joystickActive = false;
    stopJoystickMotion();
  };

  area.addEventListener('touchstart', start, {passive:false});
  window.addEventListener('touchmove', move, {passive:false});
  window.addEventListener('touchend', end, {passive:false});
  area.addEventListener('pointerdown', start);
  window.addEventListener('pointermove', move);
  window.addEventListener('pointerup', end);
}









function getTaskCategories(){
  const configured=Array.isArray(state.gameRules?.taskCategories)?state.gameRules.taskCategories:[];
  const fromTasks=Array.isArray(state.tasks)?state.tasks.map(t=>t.category).filter(Boolean):[];
  return [...new Set([...configured,...fromTasks])];
  renderTeamActionLeaderboard();
}
function refreshTaskCategoryUI(){
  const categories=getTaskCategories();
  const filter=document.getElementById('taskCategoryFilter');
  if(filter){
    const current=filter.value;
    filter.innerHTML='<option value="all">همه دسته‌بندی‌ها</option>'+categories.map(c=>`<option value="${escapeHtml(c)}">${escapeHtml(c)}</option>`).join('');
    if([...filter.options].some(o=>o.value===current))filter.value=current;
  }
  const input=document.getElementById('taskCategoryInput');
  if(input){
    input.setAttribute('list','taskCategorySuggestions');
    let dl=document.getElementById('taskCategorySuggestions');
    if(!dl){
      dl=document.createElement('datalist');dl.id='taskCategorySuggestions';document.body.appendChild(dl);
    }
    dl.innerHTML=categories.map(c=>`<option value="${escapeHtml(c)}"></option>`).join('');
  }
}
function renderCategoryManager(){
  const list=document.getElementById('categoryManagerList');if(!list)return;
  const categories=Array.isArray(state.gameRules?.taskCategories)?state.gameRules.taskCategories:[];
  list.innerHTML=categories.length?categories.map((c,i)=>`<div class="category-row">
    <input value="${escapeHtml(c)}" data-category-index="${i}" maxlength="40" />
    <div class="category-row-actions">
      <button data-category-action="save" data-index="${i}">✓</button>
      <button class="delete" data-category-action="delete" data-index="${i}">🗑</button>
    </div>
  </div>`).join(''):'<div class="task-note">هنوز دسته‌بندی تعریف نشده.</div>';
}
function openCategoryManager(){
  renderCategoryManager();
  const e=document.getElementById('categoryManager');e.classList.add('active');e.setAttribute('aria-hidden','false');
}
function closeCategoryManager(){
  const e=document.getElementById('categoryManager');e.classList.remove('active');e.setAttribute('aria-hidden','true');
}
function addCategory(event){
  event.preventDefault();
  const input=document.getElementById('newCategoryInput'),name=input.value.trim();if(!name)return;
  state.gameRules.taskCategories=Array.isArray(state.gameRules.taskCategories)?state.gameRules.taskCategories:[];
  if(!state.gameRules.taskCategories.includes(name))state.gameRules.taskCategories.push(name);
  input.value='';saveState();renderCategoryManager();refreshTaskCategoryUI();showToast('دسته‌بندی اضافه شد');
}
function handleCategoryActions(event){
  const b=event.target.closest('[data-category-action]');if(!b)return;
  const i=Number(b.dataset.index),categories=state.gameRules.taskCategories||[];
  if(!Number.isInteger(i)||!categories[i])return;
  if(b.dataset.categoryAction==='save'){
    const input=document.querySelector(`[data-category-index="${i}"]`),next=input?.value.trim();
    if(!next)return;
    const old=categories[i];categories[i]=next;
    state.tasks.forEach(t=>{if(t.category===old)t.category=next;});
    saveState();renderCategoryManager();refreshTaskCategoryUI();renderTasks();showToast('دسته‌بندی ویرایش شد');
  }else if(b.dataset.categoryAction==='delete'){
    const old=categories[i];
    if(!confirm(`دسته‌بندی «${old}» حذف شود؟ کارهای قبلی حذف نمی‌شوند.`))return;
    state.gameRules.taskCategories=categories.filter((_,idx)=>idx!==i);
    saveState();renderCategoryManager();refreshTaskCategoryUI();renderTasks();showToast('دسته‌بندی حذف شد');
  }
}
function renderTeamActionLeaderboard(){
  const wrap=document.getElementById('teamActionLeaderboard');if(!wrap)return;
  const counts={};
  (state.networkActions||[]).forEach(a=>{
    const name=(a.referrer||'').trim();if(!name)return;
    counts[name]=(counts[name]||0)+1;
  });
  const rows=Object.entries(counts).sort((a,b)=>b[1]-a[1]).slice(0,20);
  wrap.innerHTML=rows.length?rows.map(([name,count],i)=>`<div class="team-action-row">
    <div class="team-action-rank">${i+1}</div>
    <div><strong>${escapeHtml(name)}</strong><small>اقدامات ثبت‌شده در CRM</small></div>
    <div class="team-action-score">${count}</div>
  </div>`).join(''):'<div class="task-note">هنوز اقدامی با نام معرف در CRM ثبت نشده.</div>';
}

function renderSettings(){
  const r=state.gameRules||defaultState.gameRules;
  const value=(id,v)=>{const e=document.getElementById(id);if(e)e.value=v;};
  value('ruleMatchMinutes',r.matchMinutes);
  value('ruleWaveSeconds',r.waveSeconds);
  value('ruleTowerDamage',r.towerDamage);
  value('ruleBaseDamage',r.baseDamage);
  value('ruleTowerHp',r.towerHp);
  value('ruleBaseHp',r.baseHp);
  value('ruleBaseXpMax',r.baseXpMax);
  value('ruleXpGrowth',r.xpGrowthPercent);
  value('ruleRankNames',(r.rankNames||[]).join('\n'));
  const rankSelect=document.getElementById('settingRankIndex');
  if(rankSelect){
    rankSelect.innerHTML=(r.rankNames||[]).map((name,i)=>`<option value="${i}">${escapeHtml(name)}</option>`).join('');
    rankSelect.value=String(Math.max(0,Math.min((r.rankNames||[]).length-1,Number(state.rankIndex)||0)));
  }
  value('settingRankTier',state.rankTier||'III');
  value('ruleTaskCategories',(r.taskCategories||[]).join('\n'));
  value('settingPlayerName',state.playerName);
  value('settingPlayerLevel',state.level);
  value('settingPlayerGold',state.gold);
  value('settingPlayerDiamonds',state.diamonds);
}
function readLines(id){
  return document.getElementById(id).value.split('\n').map(x=>x.trim()).filter(Boolean);
}
function saveGameRules(){
  const nextXpMax=Math.max(100,Number(document.getElementById('ruleBaseXpMax').value)||8000);
  const nextRankNames=readLines('ruleRankNames');
  state.gameRules={
    matchMinutes:Math.max(1,Number(document.getElementById('ruleMatchMinutes').value)||30),
    waveSeconds:Math.max(10,Number(document.getElementById('ruleWaveSeconds').value)||45),
    towerDamage:Math.max(1,Number(document.getElementById('ruleTowerDamage').value)||34),
    baseDamage:Math.max(1,Number(document.getElementById('ruleBaseDamage').value)||25),
    towerHp:Math.max(10,Number(document.getElementById('ruleTowerHp').value)||100),
    baseHp:Math.max(10,Number(document.getElementById('ruleBaseHp').value)||100),
    baseXpMax:nextXpMax,
    xpGrowthPercent:Math.max(0,Number(document.getElementById('ruleXpGrowth').value)||16),
    rankNames:nextRankNames.length?nextRankNames:[...defaultState.gameRules.rankNames],
    taskCategories:readLines('ruleTaskCategories')
  };
  state.xpMax=nextXpMax;
  state.rankIndex=Math.max(0,Math.min(state.gameRules.rankNames.length-1,Number(document.getElementById('settingRankIndex').value)||0));
  state.rankTier=document.getElementById('settingRankTier').value||'III';
  state.rank=currentRankText();
  state.playerName=document.getElementById('settingPlayerName').value.trim()||'بازیکن';
  state.level=Math.max(1,Number(document.getElementById('settingPlayerLevel').value)||1);
  state.gold=Math.max(0,Number(document.getElementById('settingPlayerGold').value)||0);
  state.diamonds=Math.max(0,Number(document.getElementById('settingPlayerDiamonds').value)||0);
  saveState();renderState();renderSettings();showToast('تنظیمات ذخیره شد');
}
function resetGameRules(){
  if(!confirm('قوانین بازی به حالت پیش‌فرض برگردد؟'))return;
  state.gameRules=JSON.parse(JSON.stringify(defaultState.gameRules));
  state.xpMax=state.gameRules.baseXpMax;
  state.rankIndex=Math.max(0,Math.min(state.gameRules.rankNames.length-1,Number(state.rankIndex)||0));
  state.rank=currentRankText();
  saveState();renderState();renderSettings();showToast('Game Rules به پیش‌فرض برگشت');
}

let activeAchievementPeriod='all';

function achievementPeriodLabel(period){
  return {daily:'روزانه',weekly:'هفتگی',monthly:'ماهانه',longterm:'بلندمدت'}[period] || period;
}
function achievementMetricLabel(metric){
  return {
    tasks:'کارهای بازی',matches:'Match',wins:'برد',minions:'Minion',towers:'Tower',
    network:'اقدام شبکه‌سازی',team:'عضو تیم',vision:'هدف Vision',manual:'دستی'
  }[metric] || metric;
}

function achievementPeriodBounds(period, now=new Date()){
  const end=new Date(now);
  if(period==='longterm') return {start:new Date(0),end:new Date(8640000000000000)};
  if(period==='daily'){
    const start=new Date(now.getFullYear(),now.getMonth(),now.getDate());
    return {start,end:new Date(start.getTime()+86400000)};
  }
  if(period==='monthly'){
    const start=new Date(now.getFullYear(),now.getMonth(),1);
    const next=new Date(now.getFullYear(),now.getMonth()+1,1);
    return {start,end:next};
  }
  // Week starts Saturday.
  const d=new Date(now.getFullYear(),now.getMonth(),now.getDate());
  const daysSinceSaturday=(d.getDay()+1)%7;
  const start=new Date(d);start.setDate(d.getDate()-daysSinceSaturday);
  return {start,end:new Date(start.getTime()+7*86400000)};
}
function achievementClaimKey(a, now=new Date()){
  if(a.period==='longterm') return 'longterm';
  if(a.period==='daily') return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  if(a.period==='monthly') return `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}`;
  const {start}=achievementPeriodBounds('weekly',now);
  return `week-${start.getFullYear()}-${String(start.getMonth()+1).padStart(2,'0')}-${String(start.getDate()).padStart(2,'0')}`;
}
function parseNetworkActionDate(a){
  if(!a?.date)return null;
  const raw=`${a.date}${a.time?`T${a.time}`:'T12:00'}`;
  const d=new Date(raw);
  return Number.isNaN(d.getTime())?null:d;
}
function inAchievementPeriod(dateValue,period){
  const d=dateValue instanceof Date?dateValue:new Date(dateValue);
  if(Number.isNaN(d.getTime()))return false;
  const {start,end}=achievementPeriodBounds(period);
  return d>=start&&d<end;
}
function achievementCurrent(a){
  if(a.metric==='manual'){
    if(a.period!=='longterm'){
      const key=achievementClaimKey(a);
      if(a.manualPeriodKey!==key){
        a.manual=0;
        a.manualPeriodKey=key;
      }
    }
    return Math.max(0,Number(a.manual)||0);
  }

  if(['tasks','matches','wins','minions','towers'].includes(a.metric)){
    if(a.period==='longterm'){
      const s=state.lifetimeStats||{};
      if(a.metric==='matches')return Number(s.matches)||0;
      if(a.metric==='wins')return Number(s.wins)||0;
      return Number(s[a.metric])||0;
    }
    const matches=(state.matchHistory||[]).filter(m=>inAchievementPeriod(m.date,a.period));
    if(a.metric==='matches')return matches.length;
    if(a.metric==='wins')return matches.filter(m=>m.victory).length;
    return matches.reduce((sum,m)=>sum+(Number(m[a.metric])||0),0);
  }

  if(a.metric==='network'){
    const actions=state.networkActions||[];
    if(a.period==='longterm')return actions.length;
    return actions.filter(x=>{
      const d=parseNetworkActionDate(x);
      return d&&inAchievementPeriod(d,a.period);
    }).length;
  }

  // Team and Vision are current-state metrics rather than event-history metrics.
  if(a.metric==='team') return Array.isArray(state.teamMembers)?state.teamMembers.length:0;
  if(a.metric==='vision') return Array.isArray(state.visionItems)?state.visionItems.filter(v=>Number(v.progress)>=100).length:0;
  return 0;
}
function achievementIsClaimed(a){
  const history=state.achievementClaims?.[a.id];
  return Boolean(history?.[achievementClaimKey(a)]);
}
function achievementStatus(a){
  if(achievementIsClaimed(a)) return 'claimed';
  const current=achievementCurrent(a);
  const target=Math.max(1,Number(a.target)||1);
  if(current>=target) return 'ready';
  if(current<=0) return 'locked';
  return 'progress';
}
function achievementStatusLabel(status){
  return {claimed:'Claim شده',ready:'آماده Claim',progress:'در حال پیشرفت',locked:'قفل'}[status] || status;
}
function renderAchievements(){
  const list=document.getElementById('achievementList'),empty=document.getElementById('achievementEmpty');
  if(!list||!empty)return;

  const q=(document.getElementById('achievementSearchInput')?.value||'').trim().toLowerCase();
  const selectPeriod=document.getElementById('achievementPeriodFilter')?.value||'all';
  const visible=state.achievements.filter(a=>{
    const hay=`${a.title} ${a.note||''} ${achievementMetricLabel(a.metric)} ${achievementPeriodLabel(a.period)}`.toLowerCase();
    return a.active!==false &&
      (!q||hay.includes(q)) &&
      (selectPeriod==='all'||a.period===selectPeriod) &&
      (activeAchievementPeriod==='all'||a.period===activeAchievementPeriod);
  });

  const statuses=state.achievements.filter(a=>a.active!==false).map(achievementStatus);
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('achievementTotalCount',statuses.length);
  set('achievementProgressCount',statuses.filter(s=>s==='progress'||s==='locked').length);
  set('achievementReadyCount',statuses.filter(s=>s==='ready').length);
  set('achievementClaimedCount',statuses.filter(s=>s==='claimed').length);

  empty.classList.toggle('hidden',visible.length>0);
  list.innerHTML=visible.map(a=>{
    const current=achievementCurrent(a);
    const target=Math.max(1,Number(a.target)||1);
    const pctValue=Math.max(0,Math.min(100,Math.round((current/target)*100)));
    const status=achievementStatus(a);
    const rewards=[
      Number(a.xp)>0?`XP +${Number(a.xp).toLocaleString('fa-IR')}`:'',
      Number(a.gold)>0?`🪙 +${Number(a.gold).toLocaleString('fa-IR')}`:'',
      Number(a.diamonds)>0?`💎 +${Number(a.diamonds).toLocaleString('fa-IR')}`:''
    ].filter(Boolean);
    return `<article class="achievement-card ${status}">
      <div class="achievement-icon">${escapeHtml(a.icon||'🏆')}</div>
      <div class="achievement-main">
        <h3>${escapeHtml(a.title)}</h3>
        <div class="achievement-meta">
          <span class="achievement-pill">${achievementPeriodLabel(a.period)}</span>
          <span class="achievement-pill">${achievementMetricLabel(a.metric)}</span>
          <span class="achievement-pill achievement-status-pill ${status}">${achievementStatusLabel(status)}</span>
        </div>
        ${a.note?`<p>${escapeHtml(a.note)}</p>`:''}
        <div class="achievement-progress-label"><span>${Number(current).toLocaleString('fa-IR')} / ${Number(target).toLocaleString('fa-IR')}</span><b>${pctValue}%</b></div>
        <div class="achievement-progress-track"><i style="width:${pctValue}%"></i></div>
        <div class="achievement-rewards">${rewards.map(r=>`<span class="achievement-reward">${r}</span>`).join('')}</div>
      </div>
      <div class="achievement-actions">
        <button class="claim" data-achievement-action="claim" data-id="${a.id}" ${status!=='ready'?'disabled':''}>Claim</button>
        <button data-achievement-action="edit" data-id="${a.id}">ویرایش</button>
        <button class="delete" data-achievement-action="delete" data-id="${a.id}">حذف</button>
      </div>
    </article>`;
  }).join('');
}
function setAchievementPeriod(period){
  activeAchievementPeriod=period;
  document.querySelectorAll('.achievement-period-tab').forEach(b=>b.classList.toggle('active',b.dataset.achievementPeriod===period));
  renderAchievements();
}
function toggleAchievementManualField(){
  const wrap=document.getElementById('achievementManualWrap');
  if(wrap)wrap.style.display=document.getElementById('achievementMetricInput').value==='manual'?'block':'none';
}
function openAchievementEditor(id=''){
  const a=id?state.achievements.find(x=>x.id===id):null;
  document.getElementById('achievementEditorTitle').textContent=a?'ویرایش دستاورد':'دستاورد جدید';
  document.getElementById('achievementIdInput').value=a?.id||'';
  document.getElementById('achievementTitleInput').value=a?.title||'';
  document.getElementById('achievementPeriodInput').value=a?.period||'daily';
  document.getElementById('achievementMetricInput').value=a?.metric||'tasks';
  document.getElementById('achievementTargetInput').value=a?.target??10;
  document.getElementById('achievementManualInput').value=a?.manual??0;
  document.getElementById('achievementXpInput').value=a?.xp??50;
  document.getElementById('achievementGoldInput').value=a?.gold??25;
  document.getElementById('achievementDiamondInput').value=a?.diamonds??0;
  document.getElementById('achievementIconInput').value=a?.icon||'🏆';
  document.getElementById('achievementActiveInput').checked=a?.active??true;
  document.getElementById('achievementNoteInput').value=a?.note||'';
  toggleAchievementManualField();
  const modal=document.getElementById('achievementEditor');modal.classList.add('active');modal.setAttribute('aria-hidden','false');
}
function closeAchievementEditor(){
  const e=document.getElementById('achievementEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');
}
function saveAchievement(event){
  event.preventDefault();
  const id=document.getElementById('achievementIdInput').value;
  const old=id?state.achievements.find(x=>x.id===id):null;
  const item={
    id:id||`achievement_${Date.now()}`,
    title:document.getElementById('achievementTitleInput').value.trim(),
    period:document.getElementById('achievementPeriodInput').value,
    metric:document.getElementById('achievementMetricInput').value,
    target:Math.max(1,Number(document.getElementById('achievementTargetInput').value)||1),
    manual:Math.max(0,Number(document.getElementById('achievementManualInput').value)||0),
    xp:Math.max(0,Number(document.getElementById('achievementXpInput').value)||0),
    gold:Math.max(0,Number(document.getElementById('achievementGoldInput').value)||0),
    diamonds:Math.max(0,Number(document.getElementById('achievementDiamondInput').value)||0),
    icon:document.getElementById('achievementIconInput').value.trim()||'🏆',
    note:document.getElementById('achievementNoteInput').value.trim(),
    active:document.getElementById('achievementActiveInput').checked,
    manualPeriodKey:(document.getElementById('achievementMetricInput').value==='manual' && document.getElementById('achievementPeriodInput').value!=='longterm')
      ? achievementClaimKey({period:document.getElementById('achievementPeriodInput').value})
      : null
  };
  if(!item.title)return;
  if(id){const i=state.achievements.findIndex(x=>x.id===id);if(i>=0)state.achievements[i]=item;}
  else state.achievements.unshift(item);
  saveState();renderAchievements();closeAchievementEditor();showToast(id?'دستاورد ویرایش شد':'دستاورد ساخته شد');
}

function claimAchievement(id){
  const a=state.achievements.find(x=>x.id===id);if(!a||achievementStatus(a)!=='ready')return;
  const key=achievementClaimKey(a);
  state.achievementClaims=state.achievementClaims||{};
  state.achievementClaims[a.id]=state.achievementClaims[a.id]||{};
  state.achievementClaims[a.id][key]=new Date().toISOString();

  state.xp += Math.max(0,Number(a.xp)||0);
  state.gold += Math.max(0,Number(a.gold)||0);
  state.diamonds += Math.max(0,Number(a.diamonds)||0);

  while(state.xp >= state.xpMax){
    state.xp -= state.xpMax;
    state.level += 1;
    state.xpMax = Math.round(state.xpMax * (1 + (Number(state.gameRules?.xpGrowthPercent)||16)/100));
  }
  if(a.metric==='manual'&&a.period!=='longterm')a.manual=0;

  saveState();
  renderState();
  renderAchievements();
  showToast(`Achievement Claim شد: ${a.title} 🎉`);
}

function handleAchievementActions(event){
  const b=event.target.closest('[data-achievement-action]');if(!b)return;
  const a=state.achievements.find(x=>x.id===b.dataset.id);if(!a)return;
  const action=b.dataset.achievementAction;
  if(action==='claim'){claimAchievement(a.id);return;}
  if(action==='edit'){openAchievementEditor(a.id);return;}
  if(action==='delete'){
    if(!confirm(`دستاورد «${a.title}» حذف شود؟`))return;
    state.achievements=state.achievements.filter(x=>x.id!==a.id);
    if(state.achievementClaims)delete state.achievementClaims[a.id];
    saveState();renderAchievements();showToast('دستاورد حذف شد');
  }
}

let activeVisionCategory='all';

function visionCategoryLabel(category){
  return {financial:'مالی',lifestyle:'سبک زندگی',growth:'رشد شخصی',family:'خانواده'}[category] || 'هدف';
}
function visionValueLabel(item){
  const value=Number(item.value)||0;
  if(item.currency==='usd') return `$${value.toLocaleString('en-US')}`;
  if(item.currency==='count') return `${value.toLocaleString('fa-IR')} واحد`;
  return `${formatCompactNumber(value)} تومان`;
}
function renderVisionYearFilter(){
  const select=document.getElementById('visionYearFilter');if(!select)return;
  const current=select.value||'all';
  const years=[...new Set(state.visionItems.map(i=>Number(i.year)).filter(Boolean))].sort((a,b)=>a-b);
  select.innerHTML='<option value="all">همه سال‌ها</option>'+years.map(y=>`<option value="${y}">${y}</option>`).join('');
  if(years.map(String).includes(current))select.value=current;else select.value='all';
}
function renderVision(){
  const wrap=document.getElementById('visionYearSections'),empty=document.getElementById('visionEmpty');
  if(!wrap||!empty)return;
  renderVisionYearFilter();

  const q=(document.getElementById('visionSearchInput')?.value||'').trim().toLowerCase();
  const yearFilter=document.getElementById('visionYearFilter')?.value||'all';

  const items=state.visionItems.filter(item=>{
    const hay=`${item.title} ${item.note||''} ${visionCategoryLabel(item.category)}`.toLowerCase();
    return (!q||hay.includes(q)) &&
      (yearFilter==='all'||String(item.year)===String(yearFilter)) &&
      (activeVisionCategory==='all'||item.category===activeVisionCategory);
  });

  const total=state.visionItems.length;
  const done=state.visionItems.filter(i=>Number(i.progress)>=100).length;
  const avg=total?Math.round(state.visionItems.reduce((s,i)=>s+(Number(i.progress)||0),0)/total):0;
  const totalValue=state.visionItems.filter(i=>i.currency==='toman').reduce((s,i)=>s+(Number(i.value)||0),0);

  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('visionTotalCount',total);
  set('visionDoneCount',done);
  set('visionAverageProgress',`${avg}%`);
  set('visionTotalValue',formatCompactNumber(totalValue));

  empty.classList.toggle('hidden',items.length>0);

  const groups={};
  items.forEach(i=>{
    const y=String(i.year||'بدون سال');
    (groups[y] ||= []).push(i);
  });

  wrap.innerHTML=Object.keys(groups).sort((a,b)=>Number(a)-Number(b)).map(year=>{
    const group=groups[year].sort((a,b)=>(Number(b.progress)||0)-(Number(a.progress)||0));
    const yearAvg=Math.round(group.reduce((s,i)=>s+(Number(i.progress)||0),0)/group.length);
    return `<section class="vision-year-block">
      <div class="vision-year-head"><h2>${escapeHtml(year)}</h2><small>${group.length} هدف • میانگین ${yearAvg}%</small></div>
      <div class="vision-grid">
        ${group.map(item=>{
          const progress=Math.max(0,Math.min(100,Number(item.progress)||0));
          const style=item.image?`style="background-image:linear-gradient(rgba(3,12,20,.12),rgba(3,12,20,.45)),url('${escapeHtml(item.image)}')"`:'';
          return `<article class="vision-card ${progress>=100?'done':''}">
            <div class="vision-card-media ${item.image?'has-image':''}" ${style}><span class="vision-emoji">${escapeHtml(item.icon||'🎯')}</span></div>
            <div class="vision-card-body">
              <h3>${escapeHtml(item.title)}</h3>
              <div class="vision-meta"><span class="vision-category-pill">${visionCategoryLabel(item.category)}</span><strong class="vision-value">${visionValueLabel(item)}</strong></div>
              ${item.note?`<p>${escapeHtml(item.note)}</p>`:''}
              <div class="vision-progress-label"><span>پیشرفت</span><b>${progress}%</b></div>
              <div class="vision-progress-track"><i style="width:${progress}%"></i></div>
              <div class="vision-card-actions">
                <button data-vision-action="edit" data-id="${item.id}">ویرایش</button>
                <button class="delete" data-vision-action="delete" data-id="${item.id}">حذف</button>
              </div>
            </div>
          </article>`;
        }).join('')}
      </div>
    </section>`;
  }).join('');
}
function setVisionCategory(category){
  activeVisionCategory=category;
  document.querySelectorAll('.vision-category-tab').forEach(b=>b.classList.toggle('active',b.dataset.visionCategory===category));
  renderVision();
}
function openVisionEditor(id=''){
  const item=id?state.visionItems.find(x=>x.id===id):null;
  document.getElementById('visionEditorTitle').textContent=item?'ویرایش هدف':'هدف جدید';
  document.getElementById('visionItemIdInput').value=item?.id||'';
  document.getElementById('visionTitleInput').value=item?.title||'';
  document.getElementById('visionYearInput').value=item?.year||1406;
  document.getElementById('visionCategoryInput').value=item?.category||'financial';
  document.getElementById('visionValueInput').value=item?.value??0;
  document.getElementById('visionCurrencyInput').value=item?.currency||'toman';
  document.getElementById('visionProgressInput').value=item?.progress??0;
  document.getElementById('visionProgressValue').textContent=`${item?.progress??0}%`;
  document.getElementById('visionIconInput').value=item?.icon||'🎯';
  document.getElementById('visionImageInput').value=item?.image||'';
  document.getElementById('visionNoteInput').value=item?.note||'';
  const modal=document.getElementById('visionItemEditor');modal.classList.add('active');modal.setAttribute('aria-hidden','false');
}
function closeVisionEditor(){const e=document.getElementById('visionItemEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function saveVisionItem(event){
  event.preventDefault();
  const id=document.getElementById('visionItemIdInput').value;
  const item={
    id:id||`vision_${Date.now()}`,
    title:document.getElementById('visionTitleInput').value.trim(),
    year:Number(document.getElementById('visionYearInput').value)||1406,
    category:document.getElementById('visionCategoryInput').value,
    value:Math.max(0,Number(document.getElementById('visionValueInput').value)||0),
    currency:document.getElementById('visionCurrencyInput').value,
    progress:Math.max(0,Math.min(100,Number(document.getElementById('visionProgressInput').value)||0)),
    icon:document.getElementById('visionIconInput').value.trim()||'🎯',
    image:document.getElementById('visionImageInput').value.trim(),
    note:document.getElementById('visionNoteInput').value.trim()
  };
  if(!item.title)return;
  if(id){const i=state.visionItems.findIndex(x=>x.id===id);if(i>=0)state.visionItems[i]=item;}else state.visionItems.push(item);
  saveState();renderVision();closeVisionEditor();showToast(id?'هدف ویرایش شد':'هدف آینده اضافه شد');
}
function handleVisionActions(event){
  const b=event.target.closest('[data-vision-action]');if(!b)return;
  const item=state.visionItems.find(x=>x.id===b.dataset.id);if(!item)return;
  if(b.dataset.visionAction==='edit'){openVisionEditor(item.id);return;}
  if(b.dataset.visionAction==='delete'){
    if(!confirm(`هدف «${item.title}» حذف شود؟`))return;
    state.visionItems=state.visionItems.filter(x=>x.id!==item.id);saveState();renderVision();showToast('هدف حذف شد');
  }
}
function eventMetricLabel(metric){
  return {sales:'فروش',gpv:'GPV',people:'تعداد نفرات',custom:'امتیاز'}[metric] || 'امتیاز';
}
function participantStatusLabel(status){
  return {qualified:'رسیده',near:'نزدیک',follow:'پیگیری',notgoing:'عدم حضور'}[status] || status;
}
function renderEvents(){
  const list=document.getElementById('eventsList'),empty=document.getElementById('eventsEmpty');
  if(!list||!empty)return;
  const q=(document.getElementById('eventSearchInput')?.value||'').trim().toLowerCase();
  const status=document.getElementById('eventStatusFilter')?.value||'all';

  const activeCount=state.events.filter(e=>e.active).length;
  const allParticipants=state.events.flatMap(e=>e.participants||[]);
  const set=(id,v)=>{const el=document.getElementById(id);if(el)el.textContent=v;};
  set('activeEventsCount',activeCount);
  set('qualifiedPeopleCount',allParticipants.filter(p=>p.status==='qualified').length);
  set('nearPeopleCount',allParticipants.filter(p=>p.status==='near').length);
  set('followPeopleCount',allParticipants.filter(p=>p.status==='follow').length);

  const filtered=state.events.filter(e=>{
    const people=(e.participants||[]).map(p=>p.name).join(' ');
    const hay=`${e.name} ${e.location||''} ${e.criteria||''} ${people}`.toLowerCase();
    return (!q||hay.includes(q))&&(status==='all'||(status==='active'?e.active:!e.active));
  });

  empty.classList.toggle('hidden',filtered.length>0);

  list.innerHTML=filtered.map(e=>{
    const participants=e.participants||[];
    const qualified=participants.filter(p=>p.status==='qualified').length;
    const near=participants.filter(p=>p.status==='near').length;
    const follow=participants.filter(p=>p.status==='follow').length;
    const notgoing=participants.filter(p=>p.status==='notgoing').length;
    const overall=participants.length?Math.round(participants.reduce((s,p)=>s+pct(p.current,p.target||e.target),0)/participants.length):0;

    return `<article class="event-card ${e.active?'':'finished'}">
      <div class="event-card-head">
        <div class="event-title">
          <strong>${escapeHtml(e.name)}</strong>
          <small>${e.date?`📅 ${escapeHtml(e.date)}`:''} ${e.location?` • 📍 ${escapeHtml(e.location)}`:''} • معیار: ${eventMetricLabel(e.metric)} ${Number(e.target||0).toLocaleString('fa-IR')}</small>
        </div>
        <div class="event-head-actions">
          <button data-event-action="edit" data-id="${e.id}">✎</button>
          <button class="delete" data-event-action="delete" data-id="${e.id}">🗑</button>
        </div>
      </div>
      ${e.criteria?`<div class="network-result">${escapeHtml(e.criteria)}</div>`:''}
      <div class="event-progress-wrap">
        <div class="event-progress-label"><span>میانگین پیشرفت افراد</span><b>${overall}%</b></div>
        <div class="event-progress-track"><i style="width:${overall}%"></i></div>
      </div>
      <div class="event-status-summary">
        <div><span>رسیده</span><b>${qualified}</b></div>
        <div><span>نزدیک</span><b>${near}</b></div>
        <div><span>پیگیری</span><b>${follow}</b></div>
        <div><span>عدم حضور</span><b>${notgoing}</b></div>
      </div>

      <div class="event-participant-head">
        <h4>افراد ایونت</h4>
        <button data-event-action="add-person" data-id="${e.id}">＋ افزودن فرد</button>
      </div>
      <div class="participant-list">
        ${participants.length?participants.map(p=>{
          const progress=pct(p.current,p.target||e.target);
          return `<div class="participant-row">
            <div class="participant-main">
              <strong>${escapeHtml(p.name)}</strong>
              <small>${Number(p.current||0).toLocaleString('fa-IR')} / ${Number(p.target||e.target||0).toLocaleString('fa-IR')} ${eventMetricLabel(e.metric)}</small>
              <div class="participant-progress"><i style="width:${progress}%"></i></div>
              <span class="participant-status ${p.status}">${participantStatusLabel(p.status)}</span>
              ${p.note?`<small>${escapeHtml(p.note)}</small>`:''}
            </div>
            <div class="participant-actions">
              <button data-participant-action="edit" data-event-id="${e.id}" data-id="${p.id}">✎</button>
              <button class="delete" data-participant-action="delete" data-event-id="${e.id}" data-id="${p.id}">🗑</button>
            </div>
          </div>`;
        }).join(''):'<div class="task-note">هنوز فردی برای این ایونت ثبت نشده.</div>'}
      </div>
    </article>`;
  }).join('');
}
function openEventEditor(id=''){
  const e=id?state.events.find(x=>x.id===id):null;
  document.getElementById('eventEditorTitle').textContent=e?'ویرایش ایونت':'ایونت جدید';
  document.getElementById('eventIdInput').value=e?.id||'';
  document.getElementById('eventNameInput').value=e?.name||'';
  document.getElementById('eventDateInput').value=e?.date||localDateInputValue();
  document.getElementById('eventLocationInput').value=e?.location||'';
  document.getElementById('eventTargetInput').value=e?.target??100;
  document.getElementById('eventMetricInput').value=e?.metric||'custom';
  document.getElementById('eventCriteriaInput').value=e?.criteria||'';
  document.getElementById('eventActiveInput').checked=e?.active??true;
  const modal=document.getElementById('eventEditor');modal.classList.add('active');modal.setAttribute('aria-hidden','false');
}
function closeEventEditor(){const e=document.getElementById('eventEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function saveEvent(event){
  event.preventDefault();
  const id=document.getElementById('eventIdInput').value;
  const old=id?state.events.find(x=>x.id===id):null;
  const item={
    id:id||`event_${Date.now()}`,
    name:document.getElementById('eventNameInput').value.trim(),
    date:document.getElementById('eventDateInput').value,
    location:document.getElementById('eventLocationInput').value.trim(),
    target:Math.max(0,Number(document.getElementById('eventTargetInput').value)||0),
    metric:document.getElementById('eventMetricInput').value,
    criteria:document.getElementById('eventCriteriaInput').value.trim(),
    active:document.getElementById('eventActiveInput').checked,
    participants:Array.isArray(old?.participants)?old.participants:[]
  };
  if(!item.name)return;
  if(id){const i=state.events.findIndex(x=>x.id===id);if(i>=0)state.events[i]=item;}else state.events.unshift(item);
  saveState();renderEvents();closeEventEditor();showToast(id?'ایونت ویرایش شد':'ایونت ساخته شد');
}
function openParticipantEditor(eventId,participantId=''){
  const e=state.events.find(x=>x.id===eventId);if(!e)return;
  const p=participantId?(e.participants||[]).find(x=>x.id===participantId):null;
  document.getElementById('participantEditorTitle').textContent=p?'ویرایش فرد':'افزودن فرد';
  document.getElementById('participantEditorSubtitle').textContent=e.name;
  document.getElementById('participantEventIdInput').value=e.id;
  document.getElementById('participantIdInput').value=p?.id||'';
  document.getElementById('participantNameInput').value=p?.name||'';
  document.getElementById('participantCurrentInput').value=p?.current??0;
  document.getElementById('participantTargetInput').value=p?.target??e.target??100;
  document.getElementById('participantStatusInput').value=p?.status||'follow';
  document.getElementById('participantNoteInput').value=p?.note||'';
  const modal=document.getElementById('eventParticipantEditor');modal.classList.add('active');modal.setAttribute('aria-hidden','false');
}
function closeParticipantEditor(){const e=document.getElementById('eventParticipantEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function saveParticipant(event){
  event.preventDefault();
  const eventId=document.getElementById('participantEventIdInput').value;
  const id=document.getElementById('participantIdInput').value;
  const e=state.events.find(x=>x.id===eventId);if(!e)return;
  e.participants=Array.isArray(e.participants)?e.participants:[];
  const p={id:id||`participant_${Date.now()}`,name:document.getElementById('participantNameInput').value.trim(),current:Math.max(0,Number(document.getElementById('participantCurrentInput').value)||0),target:Math.max(0,Number(document.getElementById('participantTargetInput').value)||0),status:document.getElementById('participantStatusInput').value,note:document.getElementById('participantNoteInput').value.trim()};
  if(!p.name)return;
  if(id){const i=e.participants.findIndex(x=>x.id===id);if(i>=0)e.participants[i]=p;}else e.participants.push(p);
  saveState();renderEvents();closeParticipantEditor();showToast(id?'فرد ویرایش شد':'فرد به ایونت اضافه شد');
}
function handleEventButtons(event){
  const b=event.target.closest('[data-event-action]');if(!b)return;
  const e=state.events.find(x=>x.id===b.dataset.id);if(!e)return;
  const a=b.dataset.eventAction;
  if(a==='edit'){openEventEditor(e.id);return;}
  if(a==='add-person'){openParticipantEditor(e.id);return;}
  if(a==='delete'){
    if(!confirm(`ایونت «${e.name}» و افراد داخل آن حذف شوند؟`))return;
    state.events=state.events.filter(x=>x.id!==e.id);saveState();renderEvents();showToast('ایونت حذف شد');
  }
}
function handleParticipantButtons(event){
  const b=event.target.closest('[data-participant-action]');if(!b)return;
  const e=state.events.find(x=>x.id===b.dataset.eventId);if(!e)return;
  const p=(e.participants||[]).find(x=>x.id===b.dataset.id);if(!p)return;
  if(b.dataset.participantAction==='edit'){openParticipantEditor(e.id,p.id);return;}
  if(b.dataset.participantAction==='delete'){
    if(!confirm(`«${p.name}» از این ایونت حذف شود؟`))return;
    e.participants=e.participants.filter(x=>x.id!==p.id);saveState();renderEvents();showToast('فرد حذف شد');
  }
}
function setShopTab(tab){
  document.querySelectorAll('.shop-tab').forEach(b=>b.classList.toggle('active',b.dataset.shopTab===tab));
  document.getElementById('heroShopPanel').classList.toggle('active',tab==='hero');
  document.getElementById('rewardShopPanel').classList.toggle('active',tab==='rewards');
  renderShop();
}
function renderShop(){
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('shopGoldBalance',Number(state.gold||0).toLocaleString('fa-IR'));
  set('shopDiamondBalance',Number(state.diamonds||0).toLocaleString('fa-IR'));
  renderHeroShop(); renderRealRewards(); renderRewardPurchases();
}
function renderHeroShop(){
  const grid=document.getElementById('heroShopGrid'); if(!grid)return;
  grid.innerHTML=state.shopItems.map(item=>{
    const owned=state.ownedShopItems.includes(item.id);
    const equipped=item.type==='style' ? state.equippedStyle===item.id : (item.heroKey && state.selectedHero===item.heroKey);
    const canBuy=Number(state.gold||0)>=Number(item.cost||0);
    return `<article class="shop-item ${owned?'':'locked'} ${equipped?'equipped':''}">
      <div class="shop-item-visual">${item.icon||'⚔'}</div>
      <h3>${escapeHtml(item.name)}</h3><p>${escapeHtml(item.note||'')}</p>
      <div class="shop-price">
        <strong>🪙 ${Number(item.cost||0).toLocaleString('fa-IR')}</strong>
        <button data-shop-buy="${item.id}" class="${owned?'owned':''}" ${(!owned&&!canBuy)?'disabled':''}>${equipped?'فعال':owned?'انتخاب':'خرید'}</button>
      </div>
    </article>`;
  }).join('');
}
function buyOrEquipShopItem(id){
  const item=state.shopItems.find(x=>x.id===id); if(!item)return;
  const owned=state.ownedShopItems.includes(id);
  if(!owned){
    if(Number(state.gold||0)<Number(item.cost||0)){showToast('Gold کافی نیست');return;}
    state.gold-=Number(item.cost||0);
    state.ownedShopItems.push(id);
  }
  if(item.type==='hero' && item.heroKey) state.selectedHero=item.heroKey;
  if(item.type==='style') state.equippedStyle=id;
  saveState();
renderState(); renderShop(); showToast(owned?'آیتم فعال شد':'خرید انجام شد');
}
function renderRealRewards(){
  const grid=document.getElementById('realRewardGrid'),empty=document.getElementById('realRewardEmpty');if(!grid||!empty)return;
  empty.classList.toggle('hidden',state.realRewards.length>0);
  grid.innerHTML=state.realRewards.map(r=>`
    <article class="shop-item">
      <div class="shop-item-visual">${escapeHtml(r.icon||'🎁')}</div>
      <h3>${escapeHtml(r.name)}</h3><p>${escapeHtml(r.note||'')}</p>
      <div class="shop-price"><strong>💎 ${Number(r.cost||0).toLocaleString('fa-IR')}</strong>
        <button data-reward-buy="${r.id}" ${Number(state.diamonds||0)<Number(r.cost||0)?'disabled':''}>دریافت</button></div>
      <div class="reward-actions"><button data-reward-edit="${r.id}">ویرایش</button><button class="delete" data-reward-delete="${r.id}">حذف</button></div>
    </article>`).join('');
}
function buyRealReward(id){
  const r=state.realRewards.find(x=>x.id===id);if(!r)return;
  if(Number(state.diamonds||0)<Number(r.cost||0)){showToast('Diamond کافی نیست');return;}
  if(!confirm(`«${r.name}» را با ${r.cost} Diamond دریافت کنی؟`))return;
  state.diamonds-=Number(r.cost||0);
  state.rewardPurchases.unshift({id:`purchase_${Date.now()}`,rewardId:r.id,name:r.name,icon:r.icon||'🎁',cost:r.cost,date:new Date().toISOString()});
  state.rewardPurchases=state.rewardPurchases.slice(0,50);
  saveState();
renderState();renderShop();showToast('پاداش واقعی باز شد 🎉');
}
function openRealRewardEditor(id=''){
  const r=id?state.realRewards.find(x=>x.id===id):null;
  document.getElementById('realRewardEditorTitle').textContent=r?'ویرایش پاداش':'افزودن پاداش واقعی';
  document.getElementById('realRewardIdInput').value=r?.id||'';
  document.getElementById('realRewardNameInput').value=r?.name||'';
  document.getElementById('realRewardCostInput').value=r?.cost||5;
  document.getElementById('realRewardIconInput').value=r?.icon||'🎁';
  document.getElementById('realRewardNoteInput').value=r?.note||'';
  const e=document.getElementById('realRewardEditor');e.classList.add('active');e.setAttribute('aria-hidden','false');
}
function closeRealRewardEditor(){const e=document.getElementById('realRewardEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function saveRealReward(event){
  event.preventDefault();
  const id=document.getElementById('realRewardIdInput').value;
  const r={id:id||`reward_${Date.now()}`,name:document.getElementById('realRewardNameInput').value.trim(),cost:Math.max(1,Number(document.getElementById('realRewardCostInput').value)||1),icon:document.getElementById('realRewardIconInput').value.trim()||'🎁',note:document.getElementById('realRewardNoteInput').value.trim()};
  if(!r.name)return;
  if(id){const i=state.realRewards.findIndex(x=>x.id===id);if(i>=0)state.realRewards[i]=r;}else state.realRewards.unshift(r);
  saveState();renderShop();closeRealRewardEditor();showToast(id?'پاداش ویرایش شد':'پاداش اضافه شد');
}
function deleteRealReward(id){
  const r=state.realRewards.find(x=>x.id===id);if(!r||!confirm(`پاداش «${r.name}» حذف شود؟`))return;
  state.realRewards=state.realRewards.filter(x=>x.id!==id);saveState();renderShop();showToast('پاداش حذف شد');
}
function renderRewardPurchases(){
  const list=document.getElementById('rewardPurchaseHistory');if(!list)return;
  if(!state.rewardPurchases.length){list.innerHTML='<div class="task-note">هنوز پاداش واقعی دریافت نکرده‌ای.</div>';return;}
  list.innerHTML=state.rewardPurchases.slice(0,10).map(p=>{
    const d=new Date(p.date);
    return `<div class="purchase-row"><div><strong>${escapeHtml(p.icon||'🎁')} ${escapeHtml(p.name)}</strong><small>${d.toLocaleDateString('fa-IR')}</small></div><b>− 💎 ${p.cost}</b></div>`;
  }).join('');
}
const TIMESHEET = {
  selectedDate: '',
  weekOffset: 0
};

function dateKey(date){
  return localDateInputValue(date);
}

function saturdayOf(date){
  const d = new Date(date);
  d.setHours(12,0,0,0);
  const day = d.getDay(); // Sun 0 ... Sat 6
  const diff = (day + 1) % 7;
  d.setDate(d.getDate() - diff);
  return d;
}

function addDays(date,days){
  const d = new Date(date);
  d.setDate(d.getDate()+days);
  return d;
}

function faDayName(date){
  return ['یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنج‌شنبه','جمعه','شنبه'][date.getDay()];
}

function faShortDayName(date){
  return ['یک','دو','سه','چهار','پنج','جمعه','شنبه'][date.getDay()];
}

function faDateLabel(date, options={month:'long',day:'numeric'}){
  try{return date.toLocaleDateString('fa-IR',options);}catch{return dateKey(date);}
}

function getVisibleWeekStart(){
  const base = saturdayOf(new Date());
  return addDays(base, TIMESHEET.weekOffset*7);
}

function weekdayIndexFromDateKey(key){
  const d = new Date(`${key}T12:00:00`);
  return d.getDay();
}

function scheduleOccursOn(schedule,date){
  const key = dateKey(date);
  if(schedule.recurring){
    const baseDate = new Date(`${schedule.date}T12:00:00`);
    return baseDate.getDay() === date.getDay() && key >= schedule.date;
  }
  return schedule.date === key;
}

function effectiveScheduleKey(schedule,date){
  return `${schedule.id}__${dateKey(date)}`;
}

function isScheduleDone(schedule,date){
  if(schedule.recurring){
    return Boolean(schedule.doneDates?.includes(dateKey(date)));
  }
  return Boolean(schedule.done);
}

function setScheduleDone(schedule,date,done){
  if(schedule.recurring){
    schedule.doneDates = Array.isArray(schedule.doneDates) ? schedule.doneDates : [];
    const key = dateKey(date);
    if(done && !schedule.doneDates.includes(key)) schedule.doneDates.push(key);
    if(!done) schedule.doneDates = schedule.doneDates.filter(d=>d!==key);
  }else{
    schedule.done = done;
  }
}

function schedulesForDate(date){
  return state.schedules
    .filter(s=>scheduleOccursOn(s,date))
    .sort((a,b)=>(a.start||'00:00').localeCompare(b.start||'00:00'));
}

function renderTimesheetWeek(){
  const wrap = document.getElementById('weekDays');
  if(!wrap) return;

  const start = getVisibleWeekStart();
  const today = dateKey(new Date());
  const selected = TIMESHEET.selectedDate || dateKey(new Date());

  const end = addDays(start,6);
  document.getElementById('weekRangeLabel').textContent =
    `${faDateLabel(start,{month:'short',day:'numeric'})} تا ${faDateLabel(end,{month:'short',day:'numeric'})}`;

  wrap.innerHTML = Array.from({length:7},(_,i)=>{
    const d=addDays(start,i), key=dateKey(d);
    const count=schedulesForDate(d).length;
    return `<button class="week-day ${key===selected?'active':''} ${key===today?'today':''}" data-date="${key}">
      <span>${faShortDayName(d)}</span>
      <strong>${d.toLocaleDateString('fa-IR',{day:'numeric'})}</strong>
      <small>${count ? `${count} برنامه` : '—'}</small>
    </button>`;
  }).join('');
}

function renderDayTimeline(){
  const date = new Date(`${TIMESHEET.selectedDate || dateKey(new Date())}T12:00:00`);
  const items = schedulesForDate(date);
  const q = (document.getElementById('scheduleSearchInput')?.value || '').trim().toLowerCase();
  const filtered = items.filter(s=>!q || `${s.title} ${s.category||''} ${s.note||''}`.toLowerCase().includes(q));

  const doneCount = items.filter(s=>isScheduleDone(s,date)).length;
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('selectedDayName', faDayName(date));
  set('selectedDayDate', faDateLabel(date,{year:'numeric',month:'long',day:'numeric'}));
  set('dayScheduleCount',items.length);
  set('dayDoneCount',doneCount);
  set('dayPendingCount',Math.max(0,items.length-doneCount));

  const list=document.getElementById('dayTimeline'), empty=document.getElementById('timesheetEmpty');
  if(!list||!empty)return;
  empty.classList.toggle('hidden',filtered.length>0);

  list.innerHTML=filtered.map(s=>{
    const done=isScheduleDone(s,date);
    return `<article class="schedule-card ${done?'done':''}">
      <div class="schedule-time"><strong>${escapeHtml(s.start||'--:--')}</strong><small>${escapeHtml(s.end||'--:--')}</small></div>
      <div class="schedule-main">
        <strong>${escapeHtml(s.title)}</strong>
        <small>${escapeHtml(s.category||'بدون دسته‌بندی')}</small>
        ${s.note?`<p>${escapeHtml(s.note)}</p>`:''}
        <div class="schedule-tags">
          ${s.recurring?'<span class="schedule-tag recurring">↻ هفتگی</span>':''}
          <span class="schedule-tag">${done?'انجام شد':'در انتظار'}</span>
        </div>
      </div>
      <div class="schedule-actions">
        <button class="${done?'undone-btn':'done-btn'}" data-schedule-action="toggle" data-id="${s.id}" title="${done?'انجام‌نشده':'انجام شد'}">${done?'↶':'✓'}</button>
        <button data-schedule-action="edit" data-id="${s.id}">✎</button>
        <button class="delete" data-schedule-action="delete" data-id="${s.id}">🗑</button>
      </div>
    </article>`;
  }).join('');
}

function renderTimesheet(){
  if(!TIMESHEET.selectedDate) TIMESHEET.selectedDate=dateKey(new Date());
  renderTimesheetWeek();
  renderDayTimeline();
  renderRecurringList();
}

function openScheduleEditor(id=''){
  const s=id?state.schedules.find(x=>x.id===id):null;
  const editor=document.getElementById('scheduleEditor');
  document.getElementById('scheduleEditorTitle').textContent=s?'ویرایش برنامه':'افزودن برنامه';
  document.getElementById('scheduleIdInput').value=s?.id||'';
  document.getElementById('scheduleTitleInput').value=s?.title||'';
  document.getElementById('scheduleDateInput').value=s?.date||TIMESHEET.selectedDate||dateKey(new Date());
  document.getElementById('scheduleCategoryInput').value=s?.category||'';
  document.getElementById('scheduleStartInput').value=s?.start||'09:00';
  document.getElementById('scheduleEndInput').value=s?.end||'10:00';
  document.getElementById('scheduleRecurringInput').checked=Boolean(s?.recurring);
  document.getElementById('scheduleNoteInput').value=s?.note||'';
  editor.classList.add('active');editor.setAttribute('aria-hidden','false');
}

function closeScheduleEditor(){
  const e=document.getElementById('scheduleEditor');
  e.classList.remove('active');e.setAttribute('aria-hidden','true');
}

function saveSchedule(event){
  event.preventDefault();
  const id=document.getElementById('scheduleIdInput').value;
  const title=document.getElementById('scheduleTitleInput').value.trim();
  if(!title)return;
  const existing=id?state.schedules.find(s=>s.id===id):null;
  const schedule={
    id:id||`schedule_${Date.now()}`,
    title,
    date:document.getElementById('scheduleDateInput').value||TIMESHEET.selectedDate||dateKey(new Date()),
    category:document.getElementById('scheduleCategoryInput').value.trim(),
    start:document.getElementById('scheduleStartInput').value,
    end:document.getElementById('scheduleEndInput').value,
    recurring:document.getElementById('scheduleRecurringInput').checked,
    note:document.getElementById('scheduleNoteInput').value.trim(),
    done:Boolean(existing?.done),
    doneDates:Array.isArray(existing?.doneDates)?existing.doneDates:[]
  };
  if(id){
    const i=state.schedules.findIndex(s=>s.id===id);
    if(i>=0)state.schedules[i]=schedule;
  }else{
    state.schedules.push(schedule);
  }
  saveState();renderTimesheet();closeScheduleEditor();
  showToast(id?'برنامه ویرایش شد':'برنامه اضافه شد');
}

function handleScheduleActions(event){
  const btn=event.target.closest('[data-schedule-action]');if(!btn)return;
  const s=state.schedules.find(x=>x.id===btn.dataset.id);if(!s)return;
  const date=new Date(`${TIMESHEET.selectedDate}T12:00:00`);

  if(btn.dataset.scheduleAction==='toggle'){
    setScheduleDone(s,date,!isScheduleDone(s,date));
    saveState();renderTimesheet();return;
  }
  if(btn.dataset.scheduleAction==='edit'){
    openScheduleEditor(s.id);return;
  }
  if(btn.dataset.scheduleAction==='delete'){
    const msg=s.recurring?`برنامه تکرارشونده «${s.title}» کامل حذف شود؟`:`برنامه «${s.title}» حذف شود؟`;
    if(!confirm(msg))return;
    state.schedules=state.schedules.filter(x=>x.id!==s.id);
    saveState();renderTimesheet();showToast('برنامه حذف شد');
  }
}

function renderRecurringList(){
  const list=document.getElementById('recurringList'),empty=document.getElementById('recurringEmpty');
  if(!list||!empty)return;
  const items=state.schedules.filter(s=>s.recurring).sort((a,b)=>(a.start||'').localeCompare(b.start||''));
  empty.classList.toggle('hidden',items.length>0);
  list.innerHTML=items.map(s=>{
    const d=new Date(`${s.date}T12:00:00`);
    return `<div class="recurring-card">
      <div><strong>${escapeHtml(s.title)}</strong><small>${faDayName(d)} • ${escapeHtml(s.start)} تا ${escapeHtml(s.end)} • ${escapeHtml(s.category||'بدون دسته‌بندی')}</small></div>
      <div class="recurring-card-actions"><button data-recurring-action="edit" data-id="${s.id}">✎</button><button class="delete" data-recurring-action="delete" data-id="${s.id}">🗑</button></div>
    </div>`;
  }).join('');
}

function openRecurringManager(){
  renderRecurringList();
  const e=document.getElementById('recurringManager');
  e.classList.add('active');e.setAttribute('aria-hidden','false');
}

function closeRecurringManager(){
  const e=document.getElementById('recurringManager');
  e.classList.remove('active');e.setAttribute('aria-hidden','true');
}

function handleRecurringActions(event){
  const btn=event.target.closest('[data-recurring-action]');if(!btn)return;
  const s=state.schedules.find(x=>x.id===btn.dataset.id);if(!s)return;
  if(btn.dataset.recurringAction==='edit'){
    closeRecurringManager();openScheduleEditor(s.id);return;
  }
  if(btn.dataset.recurringAction==='delete'){
    if(!confirm(`برنامه تکرارشونده «${s.title}» حذف شود؟`))return;
    state.schedules=state.schedules.filter(x=>x.id!==s.id);
    saveState();renderTimesheet();renderRecurringList();showToast('برنامه تکرارشونده حذف شد');
  }
}

function networkTypeLabel(type){
  return {connect:'ارتباط‌سازی',preconsult:'پیش‌مشاوره',invite:'دعوت',presentation:'معرفی کار',followup:'فالوآپ'}[type] || 'اقدام';
}
function localDateInputValue(date=new Date()){
  const pad=n=>String(n).padStart(2,'0');
  return `${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
}
function localTimeInputValue(date=new Date()){
  const pad=n=>String(n).padStart(2,'0');
  return `${pad(date.getHours())}:${pad(date.getMinutes())}`;
}
function localDateTimeInputValue(date=new Date()){return `${localDateInputValue(date)}T${localTimeInputValue(date)}`;}
function actionDateObj(action){
  const d=new Date(`${action.date||localDateInputValue()}T${action.time||'00:00'}`);
  return Number.isNaN(d.getTime())?new Date(0):d;
}
function sameLocalDay(a,b){return a.getFullYear()===b.getFullYear()&&a.getMonth()===b.getMonth()&&a.getDate()===b.getDate();}
function startOfWeek(date){
  const d=new Date(date), day=d.getDay(), diff=(day+1)%7;
  d.setDate(d.getDate()-diff); d.setHours(0,0,0,0); return d;
}
function allOpenFollowups(){
  const rows=[];
  state.networkActions.forEach(action=>(action.nextActions||[]).forEach((next,slot)=>{
    if(next?.type&&!next.completed) rows.push({action,next,slot});
  }));
  return rows.sort((a,b)=>{
    const ad=a.next.dueAt?new Date(a.next.dueAt).getTime():Infinity;
    const bd=b.next.dueAt?new Date(b.next.dueAt).getTime():Infinity;
    return ad-bd;
  });
}
function renderNetworkStats(){
  const now=new Date(), weekStart=startOfWeek(now), actions=state.networkActions||[];
  const prospects=new Set(actions.map(a=>(a.prospect||'').trim()).filter(Boolean));
  const set=(id,v)=>{const e=document.getElementById(id);if(e)e.textContent=v;};
  set('networkTodayCount',actions.filter(a=>sameLocalDay(actionDateObj(a),now)).length);
  set('networkWeekCount',actions.filter(a=>actionDateObj(a)>=weekStart).length);
  set('networkOpenFollowups',allOpenFollowups().length);
  set('networkProspectCount',prospects.size);
  ['connect','preconsult','invite','presentation','followup'].forEach(type=>{
    const e=document.querySelector(`[data-network-count="${type}"]`);
    if(e)e.textContent=actions.filter(a=>a.type===type).length;
  });
}
function renderNetworkActions(){
  const list=document.getElementById('networkActionList'), empty=document.getElementById('networkActionEmpty');
  if(!list||!empty)return;
  const q=(document.getElementById('networkSearchInput')?.value||'').trim().toLowerCase();
  const typeFilter=document.getElementById('networkTypeFilter')?.value||'all';
  const filtered=[...state.networkActions].sort((a,b)=>actionDateObj(b)-actionDateObj(a)).filter(a=>{
    const hay=`${a.prospect} ${a.referrer||''} ${a.advisor||''} ${a.result||''}`.toLowerCase();
    return (!q||hay.includes(q))&&(typeFilter==='all'||a.type===typeFilter);
  });
  empty.classList.toggle('hidden',filtered.length>0);
  list.innerHTML=filtered.map(a=>`
    <article class="network-card">
      <div class="network-card-head">
        <div class="network-person"><strong>${escapeHtml(a.prospect)}</strong><small>${escapeHtml(a.referrer||'بدون معرف')} • مشاور: ${escapeHtml(a.advisor||'—')}</small></div>
        <div class="network-card-actions"><span class="network-type ${a.type}">${networkTypeLabel(a.type)}</span><button data-network-action="edit" data-id="${a.id}">✎</button><button class="delete" data-network-action="delete" data-id="${a.id}">🗑</button></div>
      </div>
      ${a.result?`<div class="network-result">${escapeHtml(a.result)}</div>`:''}
      <div class="network-meta"><span>📅 ${escapeHtml(a.date||'')}</span><span>🕒 ${escapeHtml(a.time||'')}</span></div>
      ${(a.nextActions||[]).length?`<div class="next-actions-preview">${a.nextActions.map(n=>`
        <div class="next-preview ${n.completed?'done':''}"><strong>${n.completed?'✓ ':''}${networkTypeLabel(n.type)}</strong><small>${n.completed?`انجام شد: ${escapeHtml(n.completedAt||'')}`:(n.dueAt?`موعد: ${escapeHtml(n.dueAt.replace('T',' '))}`:'بدون زمان')}</small></div>
      `).join('')}</div>`:''}
    </article>`).join('');
}
function renderNetworkFollowups(){
  const list=document.getElementById('networkFollowupList'), empty=document.getElementById('networkFollowupEmpty');
  if(!list||!empty)return;
  const now=new Date(), rows=allOpenFollowups();
  empty.classList.toggle('hidden',rows.length>0);
  list.innerHTML=rows.map(({action,next,slot})=>{
    const due=next.dueAt?new Date(next.dueAt):null;
    const overdue=due&&!Number.isNaN(due.getTime())&&due<now;
    return `<article class="followup-card ${overdue?'overdue':''}">
      <div class="followup-head"><div><strong>${escapeHtml(action.prospect)} — ${networkTypeLabel(next.type)}</strong><small>از اقدام ${networkTypeLabel(action.type)} • معرف: ${escapeHtml(action.referrer||'—')}</small></div><span class="followup-due">${next.dueAt?escapeHtml(next.dueAt.replace('T',' ')):'بدون زمان'}</span></div>
      <div class="followup-actions"><button class="followup-skip" data-followup-action="skip" data-id="${action.id}" data-slot="${slot}">حذف این پیگیری</button><button class="followup-complete" data-followup-action="complete" data-id="${action.id}" data-slot="${slot}">✓ انجام شد</button></div>
    </article>`;
  }).join('');
}
function renderNetworking(){renderNetworkStats();renderNetworkActions();renderNetworkFollowups();}
function setNetworkTab(tab){
  document.querySelectorAll('.network-tab').forEach(b=>b.classList.toggle('active',b.dataset.networkTab===tab));
  document.getElementById('networkActionsPanel').classList.toggle('active',tab==='actions');
  document.getElementById('networkFollowupsPanel').classList.toggle('active',tab==='followups');
  renderNetworking();
}
function openNetworkActionEditor(id=''){
  const a=id?state.networkActions.find(x=>x.id===id):null, editor=document.getElementById('networkActionEditor');
  document.getElementById('networkActionEditorTitle').textContent=a?'ویرایش اقدام':'ثبت اقدام شبکه‌سازی';
  document.getElementById('networkActionIdInput').value=a?.id||'';
  document.getElementById('networkProspectInput').value=a?.prospect||'';
  document.getElementById('networkActionTypeInput').value=a?.type||'connect';
  document.getElementById('networkReferrerInput').value=a?.referrer||'';
  document.getElementById('networkAdvisorInput').value=a?.advisor||'';
  document.getElementById('networkDateInput').value=a?.date||localDateInputValue();
  document.getElementById('networkTimeInput').value=a?.time||localTimeInputValue();
  document.getElementById('networkResultInput').value=a?.result||'';
  const n1=a?.nextActions?.[0]||{}, n2=a?.nextActions?.[1]||{};
  document.getElementById('networkNext1TypeInput').value=n1.type||'';
  document.getElementById('networkNext1DateInput').value=n1.dueAt||'';
  document.getElementById('networkNext2TypeInput').value=n2.type||'';
  document.getElementById('networkNext2DateInput').value=n2.dueAt||'';
  editor.classList.add('active'); editor.setAttribute('aria-hidden','false');
}
function closeNetworkActionEditor(){const e=document.getElementById('networkActionEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function nextActionFromInputs(typeId,dateId,existing={}){
  const type=document.getElementById(typeId).value,dueAt=document.getElementById(dateId).value;
  if(!type)return null;
  return {type,dueAt,completed:Boolean(existing?.completed),completedAt:existing?.completedAt||'',completedResult:existing?.completedResult||''};
}
function saveNetworkAction(event){
  event.preventDefault();
  const id=document.getElementById('networkActionIdInput').value, prospect=document.getElementById('networkProspectInput').value.trim();
  if(!prospect)return;
  const old=id?state.networkActions.find(a=>a.id===id):null, oldNext=old?.nextActions||[];
  const nextActions=[
    nextActionFromInputs('networkNext1TypeInput','networkNext1DateInput',oldNext[0]),
    nextActionFromInputs('networkNext2TypeInput','networkNext2DateInput',oldNext[1])
  ].filter(Boolean);
  const a={id:id||`network_${Date.now()}`,prospect,type:document.getElementById('networkActionTypeInput').value,referrer:document.getElementById('networkReferrerInput').value.trim(),advisor:document.getElementById('networkAdvisorInput').value.trim(),date:document.getElementById('networkDateInput').value||localDateInputValue(),time:document.getElementById('networkTimeInput').value||localTimeInputValue(),result:document.getElementById('networkResultInput').value.trim(),nextActions};
  if(id){const i=state.networkActions.findIndex(x=>x.id===id);if(i>=0)state.networkActions[i]=a;}else state.networkActions.unshift(a);
  saveState();renderNetworking();closeNetworkActionEditor();showToast(id?'اقدام ویرایش شد':'اقدام جدید ثبت شد');
}
function handleNetworkActionButtons(event){
  const b=event.target.closest('[data-network-action]');if(!b)return;
  const a=state.networkActions.find(x=>x.id===b.dataset.id);if(!a)return;
  if(b.dataset.networkAction==='edit'){openNetworkActionEditor(a.id);return;}
  if(b.dataset.networkAction==='delete'){
    if(!confirm(`اقدام «${a.prospect}» حذف شود؟`))return;
    state.networkActions=state.networkActions.filter(x=>x.id!==a.id);saveState();renderNetworking();showToast('اقدام حذف شد');
  }
}
function openFollowupCompleteEditor(actionId,slot){
  const a=state.networkActions.find(x=>x.id===actionId), n=a?.nextActions?.[Number(slot)];if(!a||!n)return;
  document.getElementById('followupActionIdInput').value=actionId;document.getElementById('followupSlotInput').value=slot;
  document.getElementById('followupCompleteSubtitle').textContent=`${a.prospect} — ${networkTypeLabel(n.type)}`;
  document.getElementById('followupCompletedAtInput').value=localDateTimeInputValue();
  document.getElementById('followupCompletedResultInput').value='';document.getElementById('followupNewNextTypeInput').value='';document.getElementById('followupNewNextDateInput').value='';
  const e=document.getElementById('followupCompleteEditor');e.classList.add('active');e.setAttribute('aria-hidden','false');
}
function closeFollowupCompleteEditor(){const e=document.getElementById('followupCompleteEditor');e.classList.remove('active');e.setAttribute('aria-hidden','true');}
function handleFollowupButtons(event){
  const b=event.target.closest('[data-followup-action]');if(!b)return;
  const a=state.networkActions.find(x=>x.id===b.dataset.id),slot=Number(b.dataset.slot),n=a?.nextActions?.[slot];if(!a||!n)return;
  if(b.dataset.followupAction==='complete'){openFollowupCompleteEditor(a.id,slot);return;}
  if(b.dataset.followupAction==='skip'){
    if(!confirm('این اقدام بعدی حذف شود؟'))return;
    a.nextActions.splice(slot,1);saveState();renderNetworking();showToast('پیگیری حذف شد');
  }
}
function saveFollowupCompletion(event){
  event.preventDefault();
  const actionId=document.getElementById('followupActionIdInput').value,slot=Number(document.getElementById('followupSlotInput').value);
  const a=state.networkActions.find(x=>x.id===actionId),n=a?.nextActions?.[slot];if(!a||!n)return;
  n.completed=true;n.completedAt=document.getElementById('followupCompletedAtInput').value||localDateTimeInputValue();n.completedResult=document.getElementById('followupCompletedResultInput').value.trim();
  const completedAt=new Date(n.completedAt), d=Number.isNaN(completedAt.getTime())?new Date():completedAt;
  state.networkActions.unshift({id:`network_${Date.now()}`,prospect:a.prospect,type:n.type,referrer:a.referrer||'',advisor:a.advisor||'',date:localDateInputValue(d),time:localTimeInputValue(d),result:n.completedResult,nextActions:[]});
  const newType=document.getElementById('followupNewNextTypeInput').value,newDate=document.getElementById('followupNewNextDateInput').value;
  if(newType)a.nextActions.push({type:newType,dueAt:newDate,completed:false,completedAt:'',completedResult:''});
  saveState();renderNetworking();closeFollowupCompleteEditor();showToast('پیگیری انجام شد و نتیجه ثبت شد');
}
function showToast(text){
  const toast = document.getElementById('toast');
  toast.textContent = text;
  toast.classList.add('show');
  setTimeout(()=>toast.classList.remove('show'), 1800);
}
function openPage(pageId){
  document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
  document.getElementById(pageId).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(b=>{
    b.classList.toggle('active', b.dataset.page === pageId);
  });
  if(pageId === 'tasksPage') renderTasks();
  if(pageId === 'statsPage'){
    renderGameStats();
    renderTeamStats();
  }
  if(pageId === 'networkPage') renderNetworking();
  if(pageId === 'timesheetPage') renderTimesheet();
  if(pageId === 'shopPage') renderShop();
  if(pageId === 'eventsPage') renderEvents();
  if(pageId === 'visionPage') renderVision();
  if(pageId === 'achievementsPage') renderAchievements();
  if(pageId === 'settingsPage') renderSettings();
  window.scrollTo({top:0, behavior:'instant'});
}
function bootToHome(){
  openPage('homePage');
}
function formatTime(total){
  const m = Math.floor(total/60).toString().padStart(2,'0');
  const s = (total%60).toString().padStart(2,'0');
  return `${m}:${s}`;
}
function startGame(){
  document.getElementById('gamePage').classList.add('active');
  document.getElementById('gamePage').setAttribute('aria-hidden','false');
  document.getElementById('bottomNav').style.display = 'none';

  remainingSeconds = (Number(state.gameRules?.matchMinutes)||30) * 60;
  document.getElementById('gameTimer').textContent = formatTime(remainingSeconds);

  // Each 30-minute match starts with a fresh battlefield.
  document.querySelectorAll('.minion-node').forEach(node=>{
    node.classList.remove('defeated','hit');
    node.style.opacity = '1';
    node.style.transform = 'translate(-50%,-50%)';
  });
  document.querySelectorAll('.tower-node').forEach(node=>{
    node.classList.remove('defeated','hit');
    node.style.opacity = '1';
    const hp = node.querySelector('.tower-hp i');
    if(hp){
      const maxHp=Number(state.gameRules?.towerHp)||100;
      hp.dataset.hp=String(maxHp);
      hp.style.width='100%';
    }
  });
  MOBA.deferredTaskIds = [];
  MOBA.laneProgress = {top:0, mid:0, bot:0};
  MOBA.baseHp = Number(state.gameRules?.baseHp)||100;
  MOBA.matchStartedAt = Date.now();
  MOBA.matchStats = {tasks:0, minions:0, towers:0, xp:0, gold:0, diamonds:0};
  MOBA.resultSaved = false;

  const resultOverlay = document.getElementById('matchResult');
  resultOverlay.classList.remove('active');
  resultOverlay.setAttribute('aria-hidden','true');

  const baseNode = document.querySelector('[data-id="enemy_base"]');
  if(baseNode){
    baseNode.classList.remove('defeated','hit');
    baseNode.style.opacity = '1';
  }
  const baseHp = document.getElementById('enemyBaseHpBar');
  if(baseHp){
    const maxHp=Number(state.gameRules?.baseHp)||100;
    baseHp.dataset.hp=String(maxHp);
    baseHp.style.width='100%';
  }

  renderLaneProgress();
  startWaveSystem();

  resetMobaHero();
  closeEncounter(false);
  setupJoystick();
  startMobaLoop();

  clearInterval(timerInterval);
  timerInterval = setInterval(()=>{
    remainingSeconds--;
    document.getElementById('gameTimer').textContent = formatTime(remainingSeconds);
    if(remainingSeconds <= 0){
      clearInterval(timerInterval);
      showToast('زمان بازی تمام شد');
      setTimeout(()=>showMatchResult(false), 900);
    }
  },1000);
}

function exitGame(){
  clearInterval(timerInterval);
  stopWaveSystem();
  stopMobaLoop();
  closeEncounter(false);
  document.getElementById('gamePage').classList.remove('active');
  document.getElementById('gamePage').setAttribute('aria-hidden','true');
  document.getElementById('bottomNav').style.display = 'grid';
  bootToHome();
}

document.querySelectorAll('.side-card').forEach(btn=>{
  btn.addEventListener('click',()=>{
    if(btn.dataset.page && document.getElementById(btn.dataset.page)){
      openPage(btn.dataset.page);
      return;
    }
    showToast(`${btn.textContent} در مرحله بعد ساخته می‌شود`);
  });
});
document.getElementById('startGameButton').addEventListener('click', startGame);
document.getElementById('exitGameButton').addEventListener('click', exitGame);
document.getElementById('centerHeroButton').addEventListener('click', resetMobaHero);
document.getElementById('closeEncounterButton').addEventListener('click', ()=>closeEncounter(true));
document.getElementById('startEncounterTaskButton').addEventListener('click', startEncounterTask);
document.getElementById('battleDoneButton').addEventListener('click', completeBattleTask);
document.getElementById('battleLaterButton').addEventListener('click', deferBattleTask);
document.getElementById('battleCancelButton').addEventListener('click', cancelBattleTask);
document.getElementById('resultHomeButton').addEventListener('click', closeMatchResultToHome);
document.getElementById('changeHeroButton').addEventListener('click', openHeroPicker);
document.getElementById('heroAvatarButton').addEventListener('click', openHeroPicker);
document.getElementById('closeHeroPicker').addEventListener('click', closeHeroPicker);

document.querySelectorAll('.gender-tab').forEach(tab=>{
  tab.addEventListener('click',()=>setGenderTab(tab.dataset.gender));
});
document.querySelectorAll('.hero-option').forEach(option=>{
  option.addEventListener('click',()=>selectHero(option.dataset.hero));
});
document.getElementById('heroPicker').addEventListener('click',(event)=>{
  if(event.target.id === 'heroPicker') closeHeroPicker();
});


document.getElementById('addTaskButton').addEventListener('click',()=>openTaskEditor());
document.getElementById('addFirstTaskButton').addEventListener('click',()=>openTaskEditor());
document.getElementById('closeTaskEditor').addEventListener('click', closeTaskEditor);
document.getElementById('taskForm').addEventListener('submit', saveTaskFromForm);
document.getElementById('taskList').addEventListener('click', handleTaskAction);
document.getElementById('taskSearchInput').addEventListener('input', renderTasks);
document.getElementById('taskCategoryFilter').addEventListener('change', renderTasks);
document.getElementById('taskEditor').addEventListener('click',(event)=>{
  if(event.target.id === 'taskEditor') closeTaskEditor();
});


document.querySelectorAll('.stats-tab').forEach(btn=>{
  btn.addEventListener('click',()=>setStatsTab(btn.dataset.statsTab));
});
document.getElementById('clearMatchHistoryButton').addEventListener('click', clearMatchHistory);


document.getElementById('addTeamMemberButton').addEventListener('click',()=>openTeamMemberEditor());
document.getElementById('closeTeamMemberEditor').addEventListener('click', closeTeamMemberEditor);
document.getElementById('teamMemberForm').addEventListener('submit', saveTeamMember);
document.getElementById('teamMemberList').addEventListener('click', handleTeamMemberAction);
document.getElementById('teamSearchInput').addEventListener('input', renderTeamMemberList);
document.getElementById('editTeamGoalsButton').addEventListener('click', openTeamGoalsEditor);
document.getElementById('closeTeamGoalsEditor').addEventListener('click', closeTeamGoalsEditor);
document.getElementById('teamGoalsForm').addEventListener('submit', saveTeamGoals);

document.getElementById('teamMemberEditor').addEventListener('click',(event)=>{
  if(event.target.id==='teamMemberEditor') closeTeamMemberEditor();
});
document.getElementById('teamGoalsEditor').addEventListener('click',(event)=>{
  if(event.target.id==='teamGoalsEditor') closeTeamGoalsEditor();
});


document.getElementById('addNetworkActionButton').addEventListener('click',()=>openNetworkActionEditor());
document.getElementById('closeNetworkActionEditor').addEventListener('click',closeNetworkActionEditor);
document.getElementById('networkActionForm').addEventListener('submit',saveNetworkAction);
document.getElementById('networkActionList').addEventListener('click',handleNetworkActionButtons);
document.getElementById('networkSearchInput').addEventListener('input',renderNetworkActions);
document.getElementById('networkTypeFilter').addEventListener('change',renderNetworkActions);
document.querySelectorAll('.network-tab').forEach(btn=>btn.addEventListener('click',()=>setNetworkTab(btn.dataset.networkTab)));
document.getElementById('networkFollowupList').addEventListener('click',handleFollowupButtons);
document.getElementById('closeFollowupCompleteEditor').addEventListener('click',closeFollowupCompleteEditor);
document.getElementById('followupCompleteForm').addEventListener('submit',saveFollowupCompletion);
document.getElementById('networkActionEditor').addEventListener('click',e=>{if(e.target.id==='networkActionEditor')closeNetworkActionEditor();});
document.getElementById('followupCompleteEditor').addEventListener('click',e=>{if(e.target.id==='followupCompleteEditor')closeFollowupCompleteEditor();});


document.getElementById('addScheduleButton').addEventListener('click',()=>openScheduleEditor());
document.getElementById('closeScheduleEditor').addEventListener('click',closeScheduleEditor);
document.getElementById('scheduleForm').addEventListener('submit',saveSchedule);
document.getElementById('dayTimeline').addEventListener('click',handleScheduleActions);
document.getElementById('scheduleSearchInput').addEventListener('input',renderDayTimeline);

document.getElementById('weekDays').addEventListener('click',event=>{
  const btn=event.target.closest('[data-date]');if(!btn)return;
  TIMESHEET.selectedDate=btn.dataset.date;
  renderTimesheet();
});

document.getElementById('prevWeekButton').addEventListener('click',()=>{
  TIMESHEET.weekOffset-=1;
  const start=getVisibleWeekStart();
  TIMESHEET.selectedDate=dateKey(start);
  renderTimesheet();
});
document.getElementById('nextWeekButton').addEventListener('click',()=>{
  TIMESHEET.weekOffset+=1;
  const start=getVisibleWeekStart();
  TIMESHEET.selectedDate=dateKey(start);
  renderTimesheet();
});

document.getElementById('openRecurringButton').addEventListener('click',openRecurringManager);
document.getElementById('closeRecurringManager').addEventListener('click',closeRecurringManager);
document.getElementById('recurringList').addEventListener('click',handleRecurringActions);

document.getElementById('scheduleEditor').addEventListener('click',e=>{if(e.target.id==='scheduleEditor')closeScheduleEditor();});
document.getElementById('recurringManager').addEventListener('click',e=>{if(e.target.id==='recurringManager')closeRecurringManager();});


document.addEventListener('click',event=>{
  const target=event.target.closest('[data-page]');
  if(!target)return;
  const pageId=target.dataset.page;
  if(pageId && document.getElementById(pageId)) openPage(pageId);
});

document.querySelectorAll('.shop-tab').forEach(btn=>btn.addEventListener('click',()=>setShopTab(btn.dataset.shopTab)));
document.getElementById('heroShopGrid').addEventListener('click',e=>{
  const b=e.target.closest('[data-shop-buy]');if(b)buyOrEquipShopItem(b.dataset.shopBuy);
});
document.getElementById('addRealRewardButton').addEventListener('click',()=>openRealRewardEditor());
document.getElementById('closeRealRewardEditor').addEventListener('click',closeRealRewardEditor);
document.getElementById('realRewardForm').addEventListener('submit',saveRealReward);
document.getElementById('realRewardGrid').addEventListener('click',e=>{
  const buy=e.target.closest('[data-reward-buy]'),edit=e.target.closest('[data-reward-edit]'),del=e.target.closest('[data-reward-delete]');
  if(buy)buyRealReward(buy.dataset.rewardBuy);
  else if(edit)openRealRewardEditor(edit.dataset.rewardEdit);
  else if(del)deleteRealReward(del.dataset.rewardDelete);
});
document.getElementById('realRewardEditor').addEventListener('click',e=>{if(e.target.id==='realRewardEditor')closeRealRewardEditor();});


document.getElementById('addEventButton').addEventListener('click',()=>openEventEditor());
document.getElementById('closeEventEditor').addEventListener('click',closeEventEditor);
document.getElementById('eventForm').addEventListener('submit',saveEvent);
document.getElementById('eventsList').addEventListener('click',event=>{
  handleEventButtons(event);
  handleParticipantButtons(event);
});
document.getElementById('eventSearchInput').addEventListener('input',renderEvents);
document.getElementById('eventStatusFilter').addEventListener('change',renderEvents);

document.getElementById('closeParticipantEditor').addEventListener('click',closeParticipantEditor);
document.getElementById('eventParticipantForm').addEventListener('submit',saveParticipant);

document.getElementById('eventEditor').addEventListener('click',e=>{if(e.target.id==='eventEditor')closeEventEditor();});
document.getElementById('eventParticipantEditor').addEventListener('click',e=>{if(e.target.id==='eventParticipantEditor')closeParticipantEditor();});


document.getElementById('addVisionItemButton').addEventListener('click',()=>openVisionEditor());
document.getElementById('closeVisionEditor').addEventListener('click',closeVisionEditor);
document.getElementById('visionItemForm').addEventListener('submit',saveVisionItem);
document.getElementById('visionYearSections').addEventListener('click',handleVisionActions);
document.getElementById('visionSearchInput').addEventListener('input',renderVision);
document.getElementById('visionYearFilter').addEventListener('change',renderVision);
document.querySelectorAll('.vision-category-tab').forEach(btn=>btn.addEventListener('click',()=>setVisionCategory(btn.dataset.visionCategory)));
document.getElementById('visionProgressInput').addEventListener('input',e=>document.getElementById('visionProgressValue').textContent=`${e.target.value}%`);
document.getElementById('visionItemEditor').addEventListener('click',e=>{if(e.target.id==='visionItemEditor')closeVisionEditor();});


document.getElementById('addAchievementButton').addEventListener('click',()=>openAchievementEditor());
document.getElementById('closeAchievementEditor').addEventListener('click',closeAchievementEditor);
document.getElementById('achievementForm').addEventListener('submit',saveAchievement);
document.getElementById('achievementList').addEventListener('click',handleAchievementActions);
document.getElementById('achievementSearchInput').addEventListener('input',renderAchievements);
document.getElementById('achievementPeriodFilter').addEventListener('change',renderAchievements);
document.querySelectorAll('.achievement-period-tab').forEach(btn=>btn.addEventListener('click',()=>setAchievementPeriod(btn.dataset.achievementPeriod)));
document.getElementById('achievementMetricInput').addEventListener('change',toggleAchievementManualField);
document.getElementById('achievementEditor').addEventListener('click',e=>{if(e.target.id==='achievementEditor')closeAchievementEditor();});


document.getElementById('saveGameRulesButton').addEventListener('click',saveGameRules);
document.getElementById('resetGameRulesButton').addEventListener('click',resetGameRules);


document.getElementById('manageCategoriesButton').addEventListener('click',openCategoryManager);
document.getElementById('closeCategoryManager').addEventListener('click',closeCategoryManager);
document.getElementById('categoryAddForm').addEventListener('submit',addCategory);
document.getElementById('categoryManagerList').addEventListener('click',handleCategoryActions);
document.getElementById('categoryManager').addEventListener('click',e=>{if(e.target.id==='categoryManager')closeCategoryManager();});

renderState();
renderGameStats();
renderTeamStats();
renderNetworking();
renderTimesheet();
renderShop();
renderEvents();
renderVision();
renderAchievements();
renderSettings();
refreshTaskCategoryUI();
renderTeamActionLeaderboard();
renderLaneProgress();
saveState();
bootToHome();
