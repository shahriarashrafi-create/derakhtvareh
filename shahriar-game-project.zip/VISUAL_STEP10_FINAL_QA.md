# Visual Step 10 — Final QA + GitHub/APK Ready

این نسخه تجمعی، Visual Step 1 تا 10 را شامل می‌شود.

## اصلاح نهایی
- نوار FOCUS MISSION از Home حذف شد تا Home فقط Lobby/Progress/Game Start باشد.
- Bottom navigation دقیقاً پنج گزینه اصلی دارد:
  خانه | کارها | آمار | تایم‌شیت | شبکه‌سازی
- آمار همچنان فقط Network Tree است.
- Gameplay در Android هنگام بازی وارد Immersive Mode می‌شود:
  Status Bar و Navigation Bar مخفی، Swipe موقت برای نمایش نوارها.
- خروج از Gameplay نوارهای Android را برمی‌گرداند.
- Workflow اصلی GitHub Actions برای ساخت APK و Native Immersive Bridge آماده است.

## QA
- JavaScript syntax: PASS
- Native installer syntax: PASS
- Duplicate HTML IDs: PASS
- Direct getElementById listener references: PASS
- Canonical bottom nav: PASS
- Capacitor appId/native package consistency: PASS
- GitHub workflow required steps: PASS
- Immersive enter/exit hooks: PASS

## نکته
APK داخل این ZIP از قبل کامپایل نشده است. GitHub Actions بعد از آپلود پروژه آن را می‌سازد.
