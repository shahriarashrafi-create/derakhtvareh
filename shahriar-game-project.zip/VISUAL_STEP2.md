# Visual Step 2 — Gameplay
- Professional portrait MOBA battlefield
- Hero spawns inside allied base
- Slower movement with acceleration and braking
- Walk animation and natural facing direction
- Gentle camera follow
- Original minion/tower/base encounter logic retained
- Custom graphical minions, towers, bases, minimap, objective HUD and controls
- 30-minute default remains controlled by Settings
