import { mkdir, copyFile, access } from 'node:fs/promises';
import { join } from 'node:path';

const src = join(process.cwd(), 'native', 'android');
const dest = join(process.cwd(), 'android', 'app', 'src', 'main', 'java', 'com', 'shahriar', 'game');

try {
  await access(join(process.cwd(), 'android'));
} catch {
  throw new Error('Android project not found. Run: npx cap add android');
}

await mkdir(dest, { recursive: true });
await copyFile(join(src, 'MainActivity.java'), join(dest, 'MainActivity.java'));
await copyFile(join(src, 'ImmersiveModePlugin.java'), join(dest, 'ImmersiveModePlugin.java'));
console.log('Installed Android immersive-mode native bridge.');
