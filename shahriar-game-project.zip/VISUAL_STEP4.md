# Visual Step 4 — Tasks + Timesheet
- Tasks redesigned as professional Battle Objective / Mission cards.
- Existing CRUD, categories, rewards, active state, search/filter retained.
- Timesheet redesigned as a tactical weekly planner.
- Existing week navigation, Persian dates, CRUD, recurring schedules, completion state and search retained.
- Visual Steps 1–3 remain included.
