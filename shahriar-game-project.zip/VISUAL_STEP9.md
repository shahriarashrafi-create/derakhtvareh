# Visual Step 9 — Android Immersive + Mobile Final QA

- During gameplay only, Android status bar and navigation bar are hidden.
- Android 11+ uses WindowInsetsController with transient swipe bars.
- Older Android uses IMMERSIVE_STICKY fallback.
- Leaving gameplay restores normal system bars.
- Returning from background/focus re-applies immersive mode if a match is active.
- Browser preview uses Fullscreen API fallback where available.
- Gameplay fills the complete modern phone viewport with 100dvh.
- GitHub Android workflow indentation was repaired.
- Workflow now automatically installs the native ImmersiveMode Capacitor plugin before APK build.
- Visual Steps 1–8 remain included.
