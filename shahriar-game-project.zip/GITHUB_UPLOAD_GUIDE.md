# راهنمای آپلود نهایی در GitHub

این ZIP طوری آماده شده که فایل‌های داخل آن مستقیماً در **ریشه Repository** قرار بگیرند.

ساختار درست Repository بعد از آپلود:

```text
.github/
  workflows/
    build-apk.yml
www/
  index.html
  styles.css
  app.js
package.json
capacitor.config.json
.gitignore
README.md
```

## نکته خیلی مهم
خود فایل ZIP را به عنوان یک فایل داخل Repository نگذار.
ZIP را از حالت فشرده خارج کن و **محتویات داخل ZIP** را Upload کن.

## بعد از Commit
1. وارد تب **Actions** شو.
2. Workflow با نام **Build Android APK** را باز کن.
3. اگر خودکار اجرا نشده بود، **Run workflow** را بزن.
4. بعد از سبز شدن Build، وارد همان Run شو.
5. پایین صفحه در بخش **Artifacts** فایل `shahriar-game-debug-apk` را بگیر.
6. داخل آن `app-debug.apk` قرار دارد.

این APK برای نصب آزمایشی Android است.
