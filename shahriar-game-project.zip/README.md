# Shahriar Game — Step 19 Final Fix & QA

این نسخه، ZIP تجمعی کامل پروژه تا پایان قدم ۱۹ است.

## اصلاحات اصلی قدم ۱۹

- اتصال واقعی Game Rules به Gameplay:
  - Match Duration
  - Wave Time
  - Tower Damage
  - Base Damage
  - Tower HP
  - Base HP

- اصلاح Hero لاکچری:
  - `luxury_man` به کلید صحیح `mid_luxury` اصلاح شد.

- اتصال واقعی آیتم‌های ظاهری فروشگاه به Hero:
  - هاله طلایی
  - تاج
  - هاله آبی
  - زره تاریک

- اصلاح Achievements دوره‌ای:
  - Daily بر اساس روز جاری
  - Weekly با شروع هفته از شنبه
  - Monthly بر اساس ماه جاری
  - Long-term به صورت دائمی
  - Claim هر دوره مستقل است و در دوره بعد دوباره قابل پیشرفت می‌شود.

- CRM → Team Stats:
  - Leaderboard اقدامات شبکه‌سازی در صفحه آمار تیم نمایش داده می‌شود.

- Settings:
  - Toast قدیمی حذف شد.
  - سقف XP فعلی واقعاً اعمال می‌شود.
  - Rank Names واقعاً به نمایش Rank متصل شدند.
  - Rank و Tier فعلی قابل انتخاب هستند.
  - مدت Match در Home نیز از تنظیمات خوانده می‌شود.

- Home:
  - فروشگاه، رویدادها، آینده‌بینی و دستاوردها همگی به صفحات واقعی خود متصل‌اند.

- Network Tree:
  - جلوگیری از ساخت حلقه در Parent/Downline اضافه شد.

## Android / GitHub

- Capacitor آماده است.
- GitHub Action ساخت Debug APK موجود است.
- Dependencyهای مستقیم Capacitor روی نسخه `7.0.0` ثابت شده‌اند.
- Workflow با `npm install --no-audit --no-fund` اجرا می‌شود.
- پوشه Android در GitHub Action در صورت نبودن به صورت خودکار ساخته می‌شود.

## QA انجام‌شده

- JavaScript با `node --check` بررسی شد.
- Duplicate HTML ID وجود ندارد.
- Audit خودکار برای اتصال Game Rules، Hero Shop، Achievements، CRM Leaderboard، Rank، XP و Navigation پاس شده است.

## ساختار آپلود

محتویات ZIP را از حالت فشرده خارج کن و فایل‌ها را مستقیم در Root ریپازیتوری GitHub آپلود کن.


## Step 20 — Pre-GitHub Fix
- `cache: npm` از GitHub Actions حذف شد تا نبود `package-lock.json` باعث توقف Setup Node نشود.
- مسیرهای تکراری Navigation حذف شدند تا `openPage()` دوبار اجرا نشود.
- Achievementهای Manual در Daily/Weekly/Monthly با شروع دوره جدید، حتی بدون Claim قبلی، خودکار Reset می‌شوند.
