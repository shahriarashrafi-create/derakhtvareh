package com.shahriar.gamification

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.ChecklistRtl
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.ShoppingBag
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Timeline
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            GamificationTheme {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    GamificationApp()
                }
            }
        }
    }
}

private val BgTop = Color(0xFF08111F)
private val BgBottom = Color(0xFF111D36)
private val Panel = Color(0xE316243D)
private val PanelSoft = Color(0xCC15253F)
private val Gold = Color(0xFFFFC857)
private val Cyan = Color(0xFF55D7FF)
private val TextMain = Color(0xFFF7FAFF)
private val TextMuted = Color(0xFFB8C6DD)
private val Pink = Color(0xFFFF77B7)
private val Green = Color(0xFF62EFA0)

@Composable
private fun GamificationTheme(content: @Composable () -> Unit) {
    MaterialTheme(content = content)
}

private enum class MainTab(val title: String) {
    HOME("خانه"),
    TASKS("کارها"),
    STATS("آمار"),
    TIMESHEET("تایم شیت"),
    NETWORK("شبکه سازی")
}

private enum class SessionMode(val title: String, val caption: String) {
    TEN("۱۰ دقیقه", "یک کار"),
    THIRTY("۳۰ دقیقه", "استاندارد"),
    SIXTY("۶۰ دقیقه", "تمرکز عمیق")
}

@Composable
private fun GamificationApp() {
    var selectedTab by remember { mutableStateOf(MainTab.HOME) }

    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            BottomBar(
                selectedTab = selectedTab,
                onTabSelected = { selectedTab = it }
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            FantasyBackground()

            when (selectedTab) {
                MainTab.HOME -> HomeScreen(innerPadding)
                MainTab.TASKS -> PlaceholderScreen(
                    innerPadding,
                    "کارها",
                    "بانک کارهای بازی، ترتیب زمانی و مدیریت کامل در نسخه بعدی."
                )
                MainTab.STATS -> PlaceholderScreen(
                    innerPadding,
                    "آمار",
                    "درختواره تیم، فروش، GPV، رشد و هدف‌ها در نسخه بعدی."
                )
                MainTab.TIMESHEET -> PlaceholderScreen(
                    innerPadding,
                    "تایم شیت",
                    "برنامه زمانی هفتگی در نسخه بعدی."
                )
                MainTab.NETWORK -> PlaceholderScreen(
                    innerPadding,
                    "شبکه سازی",
                    "ثبت پراسپکت، معرف، مشاور معرف و اقدامات بعدی در نسخه بعدی."
                )
            }
        }
    }
}

@Composable
private fun FantasyBackground() {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(BgTop, BgBottom, Color(0xFF09101D))
                )
            )
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            drawCircle(
                color = Cyan.copy(alpha = 0.08f),
                radius = size.minDimension * 0.35f,
                center = Offset(size.width * 0.80f, size.height * 0.18f)
            )
            drawCircle(
                color = Gold.copy(alpha = 0.07f),
                radius = size.minDimension * 0.28f,
                center = Offset(size.width * 0.16f, size.height * 0.68f)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.04f),
                radius = size.minDimension * 0.54f,
                center = Offset(size.width * 0.55f, size.height * 0.45f),
                style = Stroke(width = 3f)
            )
            repeat(18) { index ->
                val x = size.width * (((index * 43) % 100) / 100f)
                val y = size.height * (((index * 67) % 100) / 100f)
                drawCircle(
                    color = Color.White.copy(alpha = 0.07f),
                    radius = 2.5f,
                    center = Offset(x, y)
                )
            }
        }
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues) {
    var selectedMode by remember { mutableStateOf(SessionMode.THIRTY) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 14.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { HeaderCard() }
        item { QuickAccessSection() }
        item { RankSection() }
        item {
            SessionModeSection(
                selected = selectedMode,
                onSelected = { selectedMode = it }
            )
        }
        item { StartGameSection(selectedMode) }
        item { TodayOverviewSection() }
    }
}

@Composable
private fun HeaderCard() {
    PanelCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Gold, Cyan))),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "ش",
                        color = BgTop,
                        fontWeight = FontWeight.Black,
                        fontSize = 24.sp
                    )
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "شهریار",
                        color = TextMain,
                        fontWeight = FontWeight.Bold,
                        fontSize = 22.sp
                    )
                    Text(
                        text = "LV.28  |  جنگجوی رشد",
                        color = TextMuted,
                        fontSize = 13.sp
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.07f))
                        .clickable { }
                        .padding(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Rounded.Settings,
                        contentDescription = "تنظیمات",
                        tint = TextMain
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("پیشرفت سطح", color = TextMuted, fontSize = 12.sp)
                Text(
                    "۶۲۴۰ / ۸۰۰۰ XP",
                    color = Gold,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            FancyProgress(0.78f)

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatChip(
                    modifier = Modifier.weight(1f),
                    title = "طلا",
                    value = "۲۴۳۷",
                    accent = Gold,
                    icon = Icons.Rounded.ShoppingBag
                )
                StatChip(
                    modifier = Modifier.weight(1f),
                    title = "الماس",
                    value = "۱۲",
                    accent = Cyan,
                    icon = Icons.Rounded.AutoAwesome
                )
                StatChip(
                    modifier = Modifier.weight(1f),
                    title = "رنک",
                    value = "حماسی III",
                    accent = Pink,
                    icon = Icons.Rounded.EmojiEvents
                )
            }
        }
    }
}

@Composable
private fun StatChip(
    modifier: Modifier,
    title: String,
    value: String,
    accent: Color,
    icon: ImageVector
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = Color.White.copy(alpha = 0.045f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.22f))
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(20.dp))
            Text(title, color = TextMuted, fontSize = 10.sp)
            Text(value, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        }
    }
}

@Composable
private fun QuickAccessSection() {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("دسترسی‌های سریع", "بخش‌های مهم بدون شلوغی صفحه")

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionCard(
                modifier = Modifier.weight(1f),
                title = "فروشگاه",
                subtitle = "پاداش واقعی با الماس",
                icon = Icons.Rounded.ShoppingBag,
                accent = Gold
            )
            QuickActionCard(
                modifier = Modifier.weight(1f),
                title = "رویدادها",
                subtitle = "ایونت‌ها و اعضا",
                icon = Icons.Rounded.Event,
                accent = Cyan
            )
        }

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            QuickActionCard(
                modifier = Modifier.weight(1f),
                title = "آینده بینی",
                subtitle = "سال‌ها، دارایی‌ها و نتایج",
                icon = Icons.Rounded.Timeline,
                accent = Pink
            )
            QuickActionCard(
                modifier = Modifier.weight(1f),
                title = "دستاوردها",
                subtitle = "روزانه تا بلندمدت",
                icon = Icons.Rounded.EmojiEvents,
                accent = Green
            )
        }
    }
}

@Composable
private fun QuickActionCard(
    modifier: Modifier,
    title: String,
    subtitle: String,
    icon: ImageVector,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(22.dp),
        color = PanelSoft,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(15.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = accent, modifier = Modifier.size(28.dp))
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(subtitle, color = TextMuted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun RankSection() {
    PanelCard {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionTitle("رنک فعلی", "هر بازی، یک قدم به ارتقا")

            Surface(
                shape = RoundedCornerShape(24.dp),
                color = Color.White.copy(alpha = 0.035f),
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.2f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "حماسی III",
                        color = TextMain,
                        fontWeight = FontWeight.Black,
                        fontSize = 27.sp
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                        repeat(5) { index ->
                            Icon(
                                imageVector = Icons.Rounded.Star,
                                contentDescription = null,
                                tint = if (index < 3) Gold else Color.White.copy(alpha = 0.15f),
                                modifier = Modifier.size(21.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    FancyProgress(0.54f)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("۵۴ / ۱۰۰ امتیاز ارتقا", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SessionModeSection(
    selected: SessionMode,
    onSelected: (SessionMode) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        SectionTitle("نوع بازی", "بر اساس زمانی که الان داری")

        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            SessionMode.values().forEach { mode ->
                val active = selected == mode
                Surface(
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onSelected(mode) },
                    shape = RoundedCornerShape(20.dp),
                    color = if (active) Color(0xFF233759) else PanelSoft,
                    border = BorderStroke(
                        1.dp,
                        if (active) Gold.copy(alpha = 0.4f) else Color.White.copy(alpha = 0.06f)
                    )
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 15.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            mode.title,
                            color = if (active) Gold else TextMain,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(mode.caption, color = TextMuted, fontSize = 10.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun StartGameSection(selectedMode: SessionMode) {
    PanelCard {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(
                "کارهای کوچک، نتایج بزرگ می‌سازند",
                color = TextMuted,
                textAlign = TextAlign.Center
            )

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { },
                shape = RoundedCornerShape(28.dp),
                color = Color.Transparent,
                border = BorderStroke(1.dp, Gold.copy(alpha = 0.5f))
            ) {
                Box(
                    modifier = Modifier
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF102649),
                                    Color(0xFF214778),
                                    Color(0xFF102649)
                                )
                            )
                        )
                        .padding(vertical = 22.dp, horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("⚔️", fontSize = 30.sp)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            "شروع بازی",
                            color = TextMain,
                            fontWeight = FontWeight.Black,
                            fontSize = 25.sp
                        )
                        Text(
                            selectedMode.title,
                            color = Gold,
                            fontWeight = FontWeight.Bold,
                            fontSize = 17.sp
                        )
                    }
                }
            }

            Text(
                "هیرو از طراحی حذف شده؛ تمرکز صفحه روی پیشرفت، انتخاب زمان و شروع بازی است.",
                color = TextMuted,
                textAlign = TextAlign.Center,
                fontSize = 11.sp,
                lineHeight = 17.sp
            )
        }
    }
}

@Composable
private fun TodayOverviewSection() {
    PanelCard {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionTitle("امروز", "یک نگاه سریع به حرکت امروز")

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                MiniMetric(
                    modifier = Modifier.weight(1f),
                    label = "بازی",
                    value = "۲",
                    accent = Cyan
                )
                MiniMetric(
                    modifier = Modifier.weight(1f),
                    label = "کار",
                    value = "۸",
                    accent = Gold
                )
                MiniMetric(
                    modifier = Modifier.weight(1f),
                    label = "شبکه سازی",
                    value = "۵",
                    accent = Green
                )
            }
        }
    }
}

@Composable
private fun MiniMetric(
    modifier: Modifier,
    label: String,
    value: String,
    accent: Color
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(18.dp),
        color = accent.copy(alpha = 0.08f),
        border = BorderStroke(1.dp, accent.copy(alpha = 0.2f))
    ) {
        Column(
            modifier = Modifier.padding(vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(value, color = accent, fontWeight = FontWeight.Black, fontSize = 21.sp)
            Text(label, color = TextMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PanelCard(content: @Composable () -> Unit) {
    Surface(
        shape = RoundedCornerShape(26.dp),
        color = Panel,
        border = BorderStroke(1.dp, Color.White.copy(alpha = 0.075f))
    ) {
        Box(modifier = Modifier.padding(18.dp)) {
            content()
        }
    }
}

@Composable
private fun FancyProgress(progress: Float) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(9.dp)
            .clip(RoundedCornerShape(999.dp))
            .background(Color.White.copy(alpha = 0.075f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(progress)
                .height(9.dp)
                .background(
                    Brush.horizontalGradient(
                        listOf(Cyan, Gold)
                    )
                )
        )
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Text(
            title,
            color = TextMain,
            fontWeight = FontWeight.Bold,
            fontSize = 19.sp
        )
        Text(
            subtitle,
            color = TextMuted,
            fontSize = 11.sp
        )
    }
}

@Composable
private fun BottomBar(
    selectedTab: MainTab,
    onTabSelected: (MainTab) -> Unit
) {
    val items = listOf(
        Triple(MainTab.HOME, Icons.Rounded.Home, "خانه"),
        Triple(MainTab.TASKS, Icons.Rounded.ChecklistRtl, "کارها"),
        Triple(MainTab.STATS, Icons.Rounded.Insights, "آمار"),
        Triple(MainTab.TIMESHEET, Icons.Rounded.Schedule, "تایم شیت"),
        Triple(MainTab.NETWORK, Icons.Rounded.Groups, "شبکه سازی")
    )

    NavigationBar(
        containerColor = Color(0xFF0D1628),
        tonalElevation = 0.dp
    ) {
        items.forEach { (tab, icon, title) ->
            NavigationBarItem(
                selected = selectedTab == tab,
                onClick = { onTabSelected(tab) },
                icon = { Icon(icon, contentDescription = title) },
                label = { Text(title, fontSize = 9.sp) },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Gold,
                    selectedTextColor = Gold,
                    indicatorColor = Gold.copy(alpha = 0.12f),
                    unselectedIconColor = TextMuted,
                    unselectedTextColor = TextMuted
                )
            )
        }
    }
}

@Composable
private fun PlaceholderScreen(
    padding: PaddingValues,
    title: String,
    description: String
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(padding)
            .padding(18.dp),
        contentAlignment = Alignment.Center
    ) {
        PanelCard {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    title,
                    color = TextMain,
                    fontWeight = FontWeight.Black,
                    fontSize = 28.sp
                )
                Text(
                    description,
                    color = TextMuted,
                    textAlign = TextAlign.Center,
                    lineHeight = 21.sp
                )
            }
        }
    }
}
