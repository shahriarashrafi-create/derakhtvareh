# ساخت APK از فایل ZIP

فایل build-apk-from-zip.yml باید یک‌بار به‌صورت واقعی در مسیر .github/workflows ریپازیتوری قرار بگیرد.

بعد از آن فقط فایل ZIP پروژه اندروید را آپلود و Commit کنید. ورک‌فلو جدیدترین ZIP را باز می‌کند، پروژه Gradle را پیدا می‌کند و APK دیباگ می‌سازد.

برای دریافت APK وارد تب Actions شوید، اجرای سبزرنگ Build APK from uploaded ZIP را باز کنید و فایل generated-debug-apk را از پایین صفحه دانلود کنید.

نکته: خود ورک‌فلو نباید فقط داخل ZIP باقی بماند؛ GitHub برای اجرای اولیه باید فایل YAML را در مسیر .github/workflows ببیند.
